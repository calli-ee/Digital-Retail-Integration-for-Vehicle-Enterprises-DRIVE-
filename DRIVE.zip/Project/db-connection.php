<?php
class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "DriveFinal";
    public $conn;
    private $isConnected = false;

    public function __construct() {
        // Create connection
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        
        // Check connection
        if ($this->conn->connect_error) {
            // Log the error 
            error_log("Database Connection Failed: " . $this->conn->connect_error);
            
            // Throw exception with a user-friendly message
            throw new Exception("Unable to connect to the database. Please try again later.");
        }

        // Set character set to support UTF-8
        $this->conn->set_charset("utf8mb4");
        
        $this->isConnected = true;
    }

    // Method to close the connection
    public function closeConnection() {
        if ($this->isConnected && $this->conn) {
            try {
                $this->conn->close();
                $this->isConnected = false;
            } catch (Exception $e) {
                error_log("Error closing database connection: " . $e->getMessage());
            }
        }
    }

    // Destructor to ensure connection is closed
    public function __destruct() {
        $this->closeConnection();
    }

    // Check if connection is active
    public function isConnected() {
        return $this->isConnected && $this->conn && $this->conn->ping();
    }
}
?>