<?php
require_once '../db-connection.php';
require_once "header.php";


$db = new Database();
$conn = $db->conn;

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $conn->real_escape_string($_POST['order_id']);
    $status = $conn->real_escape_string($_POST['status']);
    $notes = $conn->real_escape_string($_POST['admin_notes']);
    
    $sql = "UPDATE Orders SET status = '$status', admin_notes = '$notes' WHERE order_id = '$order_id'";
    
    if ($conn->query($sql)) {
        $_SESSION['success'] = "Order status updated successfully";
    } else {
        $_SESSION['error'] = "Error updating order status: " . $conn->error;
    }
    
    header('Location: orders.php');
    exit;
}

// Get all orders with user and vehicle info
$sql = "SELECT o.*, u.full_name, u.email, u.phone, v.brand, v.model, v.image_url, vi.price 
        FROM Orders o
        JOIN Users u ON o.user_id = u.user_id
        JOIN Vehicle v ON o.vehicle_id = v.vehicle_id
        JOIN VehicleInventory vi ON o.vehicle_id = vi.vehicle_id
        ORDER BY o.order_date DESC";
$result = $conn->query($sql);
$orders = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management - DRIVE Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #ffa31a;
            --primary-dark: #e69117;
            --dark-color: #1b1b1b;
            --light-color: #ffffff;
            --gray-color: #f5f5f5;
            --text-color: #333333;
            --border-color: #e0e0e0;
            --success-color: #28a745;
            --error-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f8f9fa;
            color: var(--text-color);
            line-height: 1.6;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 2rem;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .page-title {
            font-size: 1.8rem;
            color: var(--dark-color);
        }

        .admin-user {
            display: flex;
            align-items: center;
        }

        .admin-user img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        /* Orders Table */
        .orders-table {
            width: 100%;
            background-color: var(--light-color);
            border-collapse: collapse;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
            border-radius: 8px;
            overflow: hidden;
        }

        .orders-table th, .orders-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .orders-table th {
            background-color: var(--primary-color);
            color: var(--dark-color);
            font-weight: 600;
        }

        .orders-table tr:hover {
            background-color: rgba(255, 163, 26, 0.05);
        }

        .status-badge {
            display: inline-block;
            padding: 0.3rem 0.6rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-pending {
            background-color: rgba(255, 193, 7, 0.2);
            color: var(--warning-color);
        }

        .status-processing {
            background-color: rgba(23, 162, 184, 0.2);
            color: var(--info-color);
        }

        .status-shipped {
            background-color: rgba(0, 123, 255, 0.2);
            color: #007bff;
        }

        .status-delivered {
            background-color: rgba(40, 167, 69, 0.2);
            color: var(--success-color);
        }

        .status-cancelled {
            background-color: rgba(220, 53, 69, 0.2);
            color: var(--error-color);
        }

        .action-btn {
            padding: 0.5rem 1rem;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 500;
            text-decoration: none;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
        }

        .action-btn i {
            margin-right: 5px;
        }

        .btn-edit {
            background-color: rgba(23, 162, 184, 0.1);
            color: var(--info-color);
            border: 1px solid rgba(23, 162, 184, 0.3);
        }

        .btn-edit:hover {
            background-color: rgba(23, 162, 184, 0.2);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: var(--light-color);
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            animation: modalFadeIn 0.3s ease;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-title {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .close-modal {
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
            transition: var(--transition);
        }

        .close-modal:hover {
            color: var(--dark-color);
        }

        .modal-body {
            padding: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-group select, .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-group select:focus, .form-group textarea:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 163, 26, 0.2);
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .btn {
            padding: 0.8rem 1.5rem;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            border: none;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: var(--dark-color);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            color: var(--light-color);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: var(--light-color);
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        /* Receipt Image Styles */
        .receipt-image {
            max-width: 150px;
            max-height: 150px;
            cursor: pointer;
            transition: var(--transition);
        }

        .receipt-image:hover {
            transform: scale(1.05);
        }

        /* Image Preview Modal */
        .image-preview-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            z-index: 1001;
            justify-content: center;
            align-items: center;
        }

        .image-preview-content {
            max-width: 90%;
            max-height: 90%;
        }

        .image-preview-content img {
            max-width: 100%;
            max-height: 100%;
            border-radius: 4px;
        }

        .close-preview {
            position: absolute;
            top: 20px;
            right: 20px;
            color: white;
            font-size: 2rem;
            cursor: pointer;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .orders-table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Include Sidebar -->
        <?php include "sidebar.php"; ?>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1 class="page-title">Order Management</h1>
            
            </div>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <table class="orders-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Receipt</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($orders as $order): 
                        $total_price = $order['price'] * $order['quantity'];
                        $order_date = date('M j, Y g:i a', strtotime($order['order_date']));
                        $status_class = 'status-' . $order['status'];
                    ?>
                        <tr>
                            <td>#<?php echo $order['order_id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($order['full_name']); ?></strong><br>
                                <?php echo htmlspecialchars($order['email']); ?><br>
                                <?php echo htmlspecialchars($order['phone']); ?>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($order['brand'] . ' ' . $order['model']); ?>
                                <?php if($order['image_url']): ?>
                                    <img src="../Admin/<?php echo htmlspecialchars($order['image_url']); ?>" 
                                         alt="<?php echo htmlspecialchars($order['brand'] . ' ' . $order['model']); ?>"
                                         style="width: 60px; height: auto; margin-top: 5px;">
                                <?php endif; ?>
                            </td>
                            <td><?php echo $order['quantity']; ?></td>
                            <td>₱<?php echo number_format($total_price, 2); ?></td>
                            <td>
                                <?php if($order['receipt_image']): ?>
                                    <img src="../Admin/<?php echo htmlspecialchars($order['receipt_image']); ?>" 
                                         alt="Receipt Image" 
                                         class="receipt-image"
                                         onclick="openImagePreview(this.src)">
                                <?php else: ?>
                                    No receipt
                                <?php endif; ?>
                            </td>
                            <td><?php echo $order_date; ?></td>
                            <td>
                                <span class="status-badge <?php echo $status_class; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button class="action-btn btn-edit edit-order" 
                                        data-order-id="<?php echo $order['order_id']; ?>"
                                        data-status="<?php echo $order['status']; ?>"
                                        data-notes="<?php echo htmlspecialchars($order['admin_notes'] ?? ''); ?>">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Order Modal -->
    <div id="editOrderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Update Order Status</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <form id="updateOrderForm" method="POST">
                    <input type="hidden" name="order_id" id="modalOrderId">
                    <input type="hidden" name="update_status" value="1">
                    
                    <div class="form-group">
                        <label for="status">Order Status</label>
                        <select name="status" id="status" required>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="admin_notes">Notes</label>
                        <textarea name="admin_notes" id="admin_notes" rows="4"></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary close-modal-btn">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Image Preview Modal -->
    <div id="imagePreviewModal" class="image-preview-modal">
        <span class="close-preview">&times;</span>
        <div class="image-preview-content">
            <img id="previewImage" src="" alt="Preview">
        </div>
    </div>

    <script>
        // Modal functionality
        const modal = document.getElementById('editOrderModal');
        const editButtons = document.querySelectorAll('.edit-order');
        const closeModal = document.querySelector('.close-modal');
        const closeModalBtn = document.querySelector('.close-modal-btn');
        
        // Open modal when edit button is clicked
        editButtons.forEach(button => {
            button.addEventListener('click', () => {
                const orderId = button.getAttribute('data-order-id');
                const status = button.getAttribute('data-status');
                const notes = button.getAttribute('data-notes');
                
                document.getElementById('modalOrderId').value = orderId;
                document.getElementById('status').value = status;
                document.getElementById('admin_notes').value = notes;
                
                modal.style.display = 'flex';
            });
        });
        
        // Close modal when X or cancel button is clicked
        closeModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        closeModalBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        // Close modal when clicking outside the modal
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Image Preview functionality
        const imagePreviewModal = document.getElementById('imagePreviewModal');
        const closePreview = document.querySelector('.close-preview');
        const previewImage = document.getElementById('previewImage');

        function openImagePreview(src) {
            previewImage.src = src;
            imagePreviewModal.style.display = 'flex';
        }

        closePreview.addEventListener('click', () => {
            imagePreviewModal.style.display = 'none';
        });

        window.addEventListener('click', (e) => {
            if (e.target === imagePreviewModal) {
                imagePreviewModal.style.display = 'none';
            }
        });
    </script>
</body>
</html>