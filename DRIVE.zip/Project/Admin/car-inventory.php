<?php 
require_once "header.php";
require_once '../db-connection.php';
include "sidebar.php"; 
$db = new Database();
$conn = $db->conn;
?>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card" style="border-top: 3px solid #ffa31a;">
                    <div class="card-header" style="background-color: #ffa31a; color: white;">
                        <h4>Vehicle Inventory Management</h4>
                        <button type="button" class="btn btn-light float-right" data-toggle="modal" data-target="#addInventoryModal">
                            <i class="fa fa-plus"></i> Add Inventory
                        </button>
                    </div>
                    <div class="card-body">
                        <!-- Message display area for feedback -->
                        <div id="message-area"></div>
                        
                        <!-- Inventory listing table -->
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="inventoryTable">
                                <thead style="background-color: #fff5e6;">
                                    <tr>
                                        <th>ID</th>
                                        <th>Vehicle</th>
                                        <th>Image</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Status</th>
                                        <th>Date Added</th>
                                        <th>Last Updated</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch all inventory items with vehicle details
                                    $query = "SELECT i.*, v.brand, v.model, v.year, v.image_url 
                                              FROM VehicleInventory i 
                                              INNER JOIN Vehicle v ON i.vehicle_id = v.vehicle_id 
                                              ORDER BY i.inventory_id DESC";
                                    $result = mysqli_query($conn, $query);
                                    
                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo '<tr>';
                                            echo '<td>' . $row['inventory_id'] . '</td>';
                                            echo '<td>' . $row['brand'] . ' ' . $row['model'] . ' (' . $row['year'] . ')</td>';
                                            echo '<td>';
                                            if (!empty($row['image_url'])) {
                                                echo '<img src="' . $row['image_url'] . '" class="img-thumbnail" width="80" alt="Vehicle Image">';
                                            } else {
                                                echo '<img src="assets/img/no-image.png" class="img-thumbnail" width="80" alt="No Image">';
                                            }
                                            echo '</td>';
                                            echo '<td>$' . number_format($row['price'], 2) . '</td>';
                                            echo '<td>' . $row['quantity'] . '</td>';
                                            
                                            // Status display with enhanced styling
                                            $statusClass = '';
                                            $statusText = ucfirst($row['status']);
                                            
                                            switch(strtolower($row['status'])) {
                                                case 'available': 
                                                    $statusClass = 'badge badge-success'; 
                                                    break;
                                                case 'sold out': 
                                                    $statusClass = 'badge badge-danger'; 
                                                    $statusText = 'Sold Out';
                                                    break;
                                            
                                                default:
                                                    $statusClass = 'badge badge-secondary';
                                            }
                                            
                                            echo '<td><span class="' . $statusClass . '" style="font-size: 85%; padding: 5px 8px;">' . $statusText . '</span></td>';
                                            
                                            echo '<td>' . date('M d, Y', strtotime($row['date_added'])) . '</td>';
                                            
                                            // Display the last_updated date if available
                                            echo '<td>';
                                            if (!empty($row['last_updated'])) {
                                                echo date('M d, Y h:i A', strtotime($row['last_updated']));
                                            } else {
                                                echo '<span class="text-muted">Not modified</span>';
                                            }
                                            echo '</td>';
                                            
                                            echo '<td>';
                                            // CHANGED: Edit button now uses btn-orange class instead of btn-info
                                            echo '<button class="btn btn-sm btn-orange edit-btn" data-id="' . $row['inventory_id'] . '"><i class="fa fa-edit"></i> Edit</button> ';
                                            echo '<button class="btn btn-sm btn-danger delete-btn" data-id="' . $row['inventory_id'] . '"><i class="fa fa-trash"></i> Delete</button>';
                                            echo '</td>';
                                            echo '</tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="9" class="text-center">No inventory items found.</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Inventory Modal -->
<div class="modal fade" id="addInventoryModal" tabindex="-1" role="dialog" aria-labelledby="addInventoryModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #ffa31a; color: white;">
                <h5 class="modal-title" id="addInventoryModalLabel">Add New Inventory</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="addInventoryForm" action="process-inventory.php" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="vehicle">Vehicle</label>
                        <select class="form-control" id="vehicle" name="vehicle_id" required>
                            <option value="">Select Vehicle</option>
                            <?php
                            // Fetch all vehicles for the dropdown
                            $vehicleQuery = "SELECT vehicle_id, brand, model, year FROM Vehicle ORDER BY brand, model";
                            $vehicleResult = mysqli_query($conn, $vehicleQuery);
                            
                            if (mysqli_num_rows($vehicleResult) > 0) {
                                while ($vehicleRow = mysqli_fetch_assoc($vehicleResult)) {
                                    echo '<option value="' . $vehicleRow['vehicle_id'] . '">' . 
                                        $vehicleRow['brand'] . ' ' . $vehicleRow['model'] . ' (' . $vehicleRow['year'] . ')' . 
                                    '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="price">Price (₱)</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="1" required>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select class="form-control" id="status" name="status" required>
                            <option value="available">Available</option>
                            <option value="sold out">Sold Out</option>
                        </select>
                    </div>
                    <input type="hidden" name="action" value="add">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" style="background-color: #ffa31a; border-color: #ffa31a;">Save Inventory</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Inventory Modal -->
<div class="modal fade" id="editInventoryModal" tabindex="-1" role="dialog" aria-labelledby="editInventoryModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #ffa31a; color: white;">
                <h5 class="modal-title" id="editInventoryModalLabel">Edit Inventory</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editInventoryForm" action="process-inventory.php" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="editVehicle">Vehicle</label>
                        <select class="form-control" id="editVehicle" name="vehicle_id" required>
                            <?php
                            // Re-query vehicles for the edit dropdown
                            mysqli_data_seek($vehicleResult, 0);
                            
                            if (mysqli_num_rows($vehicleResult) > 0) {
                                while ($vehicleRow = mysqli_fetch_assoc($vehicleResult)) {
                                    echo '<option value="' . $vehicleRow['vehicle_id'] . '">' . 
                                        $vehicleRow['brand'] . ' ' . $vehicleRow['model'] . ' (' . $vehicleRow['year'] . ')' . 
                                    '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="editPrice">Price ($)</label>
                        <input type="number" class="form-control" id="editPrice" name="price" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="editQuantity">Quantity</label>
                        <input type="number" class="form-control" id="editQuantity" name="quantity" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="editStatus">Status</label>
                        <select class="form-control" id="editStatus" name="status" required>
                            <option value="available">Available</option>
                            <option value="sold out">Sold Out</option>
                        
                        </select>
                    </div>
                    <input type="hidden" id="editInventoryId" name="inventory_id">
                    <input type="hidden" name="action" value="edit">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" style="background-color: #ffa31a; border-color: #ffa31a;">Update Inventory</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteInventoryModal" tabindex="-1" role="dialog" aria-labelledby="deleteInventoryModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteInventoryModalLabel">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this inventory item? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" id="confirmDelete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced CSS for status badges and orange buttons -->
<style>
/* Additional styles for status badges to ensure visibility */
.badge {
    display: inline-block;
    min-width: 70px;
    text-align: center;
    font-weight: 500;
}
.badge-success {
    background-color: #28a745;
    color: white;
}
.badge-danger {
    background-color: #dc3545;
    color: white;
}
.badge-warning {
    background-color: #ffc107;
    color: #212529;
}
.badge-secondary {
    background-color: #6c757d;
    color: white;
}

/* Orange button styles for consistent theming */
.btn-orange {
    background-color: #ffa31a;
    border-color: #ffa31a;
    color: white;
}

.btn-orange:hover {
    background-color: #e6921a;
    border-color: #e6921a;
    color: white;
}

.btn-orange:focus, .btn-orange.focus {
    box-shadow: 0 0 0 0.2rem rgba(255, 163, 26, 0.5);
}

.btn-orange:active, .btn-orange.active {
    background-color: #cc7a15;
    border-color: #cc7a15;
    color: white;
}

/* ADD THE NEW PAGINATION STYLES HERE */
/* FIXED PAGINATION STYLES - Replace the existing pagination CSS with this */

/* Reset and clean up pagination wrapper */
.dataTables_wrapper .dataTables_paginate {
    padding-top: 0.5em;
    text-align: right;
}

/* Clean base styles for pagination buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button {
    box-sizing: border-box !important;
    display: inline-block !important;
    min-width: 1.5em !important;
    padding: 0.5em 1em !important;
    margin-left: 2px !important;
    text-align: center !important;
    text-decoration: none !important;
    cursor: pointer !important;
    color: #333 !important;
    border: 1px solid #ddd !important;
    border-radius: 4px !important;
    background: #fff !important;
    transition: all 0.3s ease !important;
    /* Remove any nested styling conflicts */
    position: relative !important;
}

/* Remove inner anchor styling that causes double boxes */
.dataTables_wrapper .dataTables_paginate .paginate_button a {
    color: inherit !important;
    text-decoration: none !important;
    display: block !important;
    padding: 0 !important;
    margin: 0 !important;
    border: none !important;
    background: transparent !important;
    width: 100% !important;
    height: 100% !important;
}

/* Hover state - single clean style */
.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    color: #fff !important;
    border-color: #ffa31a !important;
    background-color: #ffa31a !important;
    text-decoration: none !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover a {
    color: #fff !important;
    text-decoration: none !important;
}

/* Active/Current page button */
.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    color: #fff !important;
    border-color: #ffa31a !important;
    background-color: #ffa31a !important;
    font-weight: bold !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current a {
    color: #fff !important;
    text-decoration: none !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
    color: #fff !important;
    border-color: #e6921a !important;
    background-color: #e6921a !important;
}

/* Disabled pagination buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
    cursor: default !important;
    color: #999 !important;
    border-color: #ddd !important;
    background-color: #f9f9f9 !important;
    opacity: 0.5 !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.disabled a {
    color: #999 !important;
    cursor: default !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
    color: #999 !important;
    border-color: #ddd !important;
    background-color: #f9f9f9 !important;
}

/* Focus state for accessibility */
.dataTables_wrapper .dataTables_paginate .paginate_button:focus {
    outline: none !important;
    box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.5) !important;
}

/* Ensure Previous/Next buttons look consistent */
.dataTables_wrapper .dataTables_paginate .paginate_button.previous,
.dataTables_wrapper .dataTables_paginate .paginate_button.next {
    font-weight: 500;
}

/* Optional: Enhanced styling for search and length controls */
.dataTables_wrapper .dataTables_filter input {
    border: 2px solid #ddd;
    border-radius: 4px;
    padding: 5px 10px;
    transition: border-color 0.3s ease;
}

.dataTables_wrapper .dataTables_filter input:focus {
    outline: none;
    border-color: #ffa31a;
    box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.2);
}

.dataTables_wrapper .dataTables_length select {
    border: 2px solid #ddd;
    border-radius: 4px;
    padding: 3px 8px;
    transition: border-color 0.3s ease;
}

.dataTables_wrapper .dataTables_length select:focus {
    outline: none;
    border-color: #ffa31a;
    box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.2);
}
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
    // Initialize DataTable if you want to use it
    $('#inventoryTable').DataTable({
        "order": [[0, "desc"]]
    });
    
    // Handle edit button click
    $(document).on('click', '.edit-btn', function() {
        var inventoryId = $(this).data('id');
        
        // Get inventory data through AJAX
        $.ajax({
            url: 'process-inventory.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'get',
                inventory_id: inventoryId
            },
            success: function(response) {
                if (response.status === 'success') {
                    var inventory = response.data;
                    
                    // Fill the edit form with inventory data
                    $('#editInventoryId').val(inventory.inventory_id);
                    $('#editVehicle').val(inventory.vehicle_id);
                    $('#editPrice').val(inventory.price);
                    $('#editQuantity').val(inventory.quantity);
                    $('#editStatus').val(inventory.status);
                    
                    // Open the edit modal
                    $('#editInventoryModal').modal('show');
                } else {
                    alert('Error loading inventory data: ' + response.message);
                }
            },
            error: function() {
                alert('Server error occurred while fetching inventory data.');
            }
        });
    });
    
    // Handle delete button click
    var deleteInventoryId;
    $(document).on('click', '.delete-btn', function() {
        deleteInventoryId = $(this).data('id');
        $('#deleteInventoryModal').modal('show');
    });
    
    // Handle delete confirmation
    $('#confirmDelete').click(function() {
        $.ajax({
            url: 'process-inventory.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'delete',
                inventory_id: deleteInventoryId
            },
            success: function(response) {
                if (response.status === 'success') {
                    // Close modal and show success message
                    $('#deleteInventoryModal').modal('hide');
                    $('#message-area').html('<div class="alert alert-success">' + response.message + '</div>');
                    
                    // Remove the deleted row from the table
                    $('button.delete-btn[data-id="' + deleteInventoryId + '"]').closest('tr').fadeOut(500, function() {
                        $(this).remove();
                        
                        // If no more rows, show empty message
                        if ($('#inventoryTable tbody tr').length === 0) {
                            $('#inventoryTable tbody').html('<tr><td colspan="9" class="text-center">No inventory items found.</td></tr>');
                        }
                    });
                } else {
                    $('#deleteInventoryModal').modal('hide');
                    $('#message-area').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            },
            error: function() {
                $('#deleteInventoryModal').modal('hide');
                $('#message-area').html('<div class="alert alert-danger">Server error occurred during deletion.</div>');
            }
        });
    });
    
    // Form submission via AJAX for add form
    $('#addInventoryForm').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    // Close modal and show success message
                    $('#addInventoryModal').modal('hide');
                    $('#addInventoryForm')[0].reset();
                    $('#message-area').html('<div class="alert alert-success">' + response.message + '</div>');
                    
                    // Reload the page to show the new inventory item
                    location.reload();
                } else {
                    $('#message-area').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            },
            error: function() {
                $('#message-area').html('<div class="alert alert-danger">Server error occurred while adding the inventory item.</div>');
            }
        });
    });
    
    // Form submission via AJAX for edit form
    $('#editInventoryForm').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    // Close modal and show success message
                    $('#editInventoryModal').modal('hide');
                    $('#message-area').html('<div class="alert alert-success">' + response.message + '</div>');
                    
                    // Reload the page to show the updated inventory
                    location.reload();
                } else {
                    $('#message-area').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            },
            error: function() {
                $('#message-area').html('<div class="alert alert-danger">Server error occurred while updating the inventory item.</div>');
            }
        });
    });
});
</script>