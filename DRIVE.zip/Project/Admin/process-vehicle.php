<?php
// Process vehicle operations (Add, Edit, Delete, Get)
require_once '../db-connection.php';
$db = new Database();
$conn = $db->conn;

// Function to sanitize input data
function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

// Handle DataTables AJAX request
if (isset($_GET['action']) && $_GET['action'] == 'get_vehicles') {
    $query = "SELECT * FROM Vehicle ORDER BY vehicle_id DESC";
    $result = mysqli_query($conn, $query);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = [
            'vehicle_id' => $row['vehicle_id'],
            'image' => !empty($row['image_url']) ? 
                '<img src="' . $row['image_url'] . '" class="img-thumbnail" style="max-width: 100px; height: auto;" alt="Vehicle Image">' : 
                '<img src="assets/img/no-image.png" class="img-thumbnail" style="max-width: 100px; height: auto;" alt="No Image">',
            'brand' => htmlspecialchars($row['brand']),
            'model' => htmlspecialchars($row['model']),
            'year' => $row['year'],
            'specifications' => htmlspecialchars($row['specifications']),
            'actions' => '<button class="btn btn-sm btn-orange edit-btn" data-id="' . $row['vehicle_id'] . '"><i class="fa fa-edit"></i> Edit</button> ' .
                         '<button class="btn btn-sm btn-danger delete-btn" data-id="' . $row['vehicle_id'] . '"><i class="fa fa-trash"></i> Delete</button>'
        ];
    }
    
    echo json_encode(['data' => $data]);
    exit;
}
// Function to handle image upload
function handleImageUpload($vehicleId = null) {
    $targetDir = "uploads/vehicles/";
    
    // Create directory if it doesn't exist
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    // Check if a file was uploaded
    if (isset($_FILES["vehicleImage"]) && $_FILES["vehicleImage"]["error"] == 0) {
        $fileName = basename($_FILES["vehicleImage"]["name"]);
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        
        // Generate a unique file name
        $newFileName = ($vehicleId ? "vehicle_" . $vehicleId : "vehicle_" . time()) . "_" . uniqid() . "." . $fileExt;
        $targetFile = $targetDir . $newFileName;
        
        // Check file size (limit to 5MB)
        if ($_FILES["vehicleImage"]["size"] > 5000000) {
            return ["status" => "error", "message" => "File is too large. Maximum size is 5MB."];
        }
        
        // Allow only certain file formats
        $allowedTypes = ["jpg", "jpeg", "png", "gif"];
        if (!in_array(strtolower($fileExt), $allowedTypes)) {
            return ["status" => "error", "message" => "Only JPG, JPEG, PNG, and GIF files are allowed."];
        }
        
        // Try to upload the file
        if (move_uploaded_file($_FILES["vehicleImage"]["tmp_name"], $targetFile)) {
            return ["status" => "success", "path" => $targetFile];
        } else {
            return ["status" => "error", "message" => "Failed to upload the image."];
        }
    }
    
    // No file uploaded or error in upload
    return ["status" => "none"];
}

// Set header to return JSON
header('Content-Type: application/json');

// Process based on the action parameter
if (isset($_POST['action'])) {
    $action = $_POST['action'];
    
    switch ($action) {
        case 'add':
            // Validate required fields
            if (empty($_POST['brand']) || empty($_POST['model']) || empty($_POST['year']) || empty($_POST['specifications'])) {
                echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
                exit;
            }
            
            // Sanitize inputs
            $brand = sanitize($conn, $_POST['brand']);
            $model = sanitize($conn, $_POST['model']);
            $year = intval($_POST['year']);
            $specifications = sanitize($conn, $_POST['specifications']);
            
            // Validate year
            if ($year < 1900 || $year > 2099) {
                echo json_encode(['status' => 'error', 'message' => 'Please enter a valid year between 1900 and 2099.']);
                exit;
            }
            
            // Insert basic vehicle info first
            $query = "INSERT INTO Vehicle (brand, model, year, specifications) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssis", $brand, $model, $year, $specifications);
            
            if ($stmt->execute()) {
                $vehicleId = $stmt->insert_id;
                
                // Handle image upload if present
                $imageResult = handleImageUpload($vehicleId);
                
                if ($imageResult["status"] === "success") {
                    // Update the vehicle record with the image path
                    $imagePath = $imageResult["path"];
                    $updateQuery = "UPDATE Vehicle SET image_url = ? WHERE vehicle_id = ?";
                    $updateStmt = $conn->prepare($updateQuery);
                    $updateStmt->bind_param("si", $imagePath, $vehicleId);
                    $updateStmt->execute();
                } elseif ($imageResult["status"] === "error") {
                    // If there was an error with the image but the vehicle was added
                    echo json_encode(['status' => 'partial', 'message' => 'Vehicle added but ' . $imageResult["message"]]);
                    exit;
                }
                
                echo json_encode(['status' => 'success', 'message' => 'Vehicle added successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error adding vehicle: ' . $stmt->error]);
            }
            break;
            
        case 'edit':
            // Validate required fields and vehicle ID
            if (empty($_POST['vehicle_id']) || empty($_POST['brand']) || empty($_POST['model']) || empty($_POST['year']) || empty($_POST['specifications'])) {
                echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
                exit;
            }
            
            // Sanitize inputs
            $vehicleId = intval($_POST['vehicle_id']);
            $brand = sanitize($conn, $_POST['brand']);
            $model = sanitize($conn, $_POST['model']);
            $year = intval($_POST['year']);
            $specifications = sanitize($conn, $_POST['specifications']);
            
            // Validate year
            if ($year < 1900 || $year > 2099) {
                echo json_encode(['status' => 'error', 'message' => 'Please enter a valid year between 1900 and 2099.']);
                exit;
            }
            
            // Update vehicle information
            $query = "UPDATE Vehicle SET brand = ?, model = ?, year = ?, specifications = ? WHERE vehicle_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssisi", $brand, $model, $year, $specifications, $vehicleId);
            
            if ($stmt->execute()) {
                // Handle image upload if present
                $imageResult = handleImageUpload($vehicleId);
                
                if ($imageResult["status"] === "success") {
                    // Update the vehicle record with the new image path
                    $imagePath = $imageResult["path"];
                    $updateQuery = "UPDATE Vehicle SET image_url = ? WHERE vehicle_id = ?";
                    $updateStmt = $conn->prepare($updateQuery);
                    $updateStmt->bind_param("si", $imagePath, $vehicleId);
                    $updateStmt->execute();
                } elseif ($imageResult["status"] === "error") {
                    // If there was an error with the image but the vehicle was updated
                    echo json_encode(['status' => 'partial', 'message' => 'Vehicle updated but ' . $imageResult["message"]]);
                    exit;
                }
                
                echo json_encode(['status' => 'success', 'message' => 'Vehicle updated successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error updating vehicle: ' . $stmt->error]);
            }
            break;
            
        case 'delete':
            // Validate vehicle ID
            if (empty($_POST['vehicle_id'])) {
                echo json_encode(['status' => 'error', 'message' => 'Vehicle ID is required.']);
                exit;
            }
            
            $vehicleId = intval($_POST['vehicle_id']);
            
            // Get the image path before deleting (to delete the file)
            $getImageQuery = "SELECT image_url FROM Vehicle WHERE vehicle_id = ?";
            $getImageStmt = $conn->prepare($getImageQuery);
            $getImageStmt->bind_param("i", $vehicleId);
            $getImageStmt->execute();
            $getImageResult = $getImageStmt->get_result();
            
            if ($getImageRow = $getImageResult->fetch_assoc()) {
                $imagePath = $getImageRow['image_url'];
            }
            
            // Delete the vehicle record
            $query = "DELETE FROM Vehicle WHERE vehicle_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $vehicleId);
            
            if ($stmt->execute()) {
                // Delete the associated image file if it exists
                if (!empty($imagePath) && file_exists($imagePath)) {
                    unlink($imagePath);
                }
                
                echo json_encode(['status' => 'success', 'message' => 'Vehicle deleted successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error deleting vehicle: ' . $stmt->error]);
            }
            break;
            
        case 'get':
            // Validate vehicle ID
            if (empty($_POST['vehicle_id'])) {
                echo json_encode(['status' => 'error', 'message' => 'Vehicle ID is required.']);
                exit;
            }
            
            $vehicleId = intval($_POST['vehicle_id']);
            
            // Get vehicle details
            $query = "SELECT * FROM Vehicle WHERE vehicle_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $vehicleId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                echo json_encode(['status' => 'success', 'data' => $row]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Vehicle not found.']);
            }
            break;
            
        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Action parameter is required.']);
}
?>