<?php
session_start();
require_once "../db-connection.php";
$db = new Database();
$conn = $db->conn;
// Check if user is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Get admin data
$admin_id = $_SESSION['admin_id'];
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/x-icon" href="/Project/sign.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --main-color: #ffa31a;
            --main-color-dark: #e69200;
            --main-color-light: #ffb84d;
        }
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            position: fixed;
            width: 250px;
        }
        .sidebar-header {
            padding: 20px;
            background-color: var(--main-color);
            text-align: center;
        }
        .sidebar-menu {
            padding: 20px 0;
            display: flex;
            flex-direction: column;
            height: calc(100vh - 80px); /* Adjust based on header height */
        }
        .sidebar-logout {
            margin-top: auto;
            padding-bottom: 20px;
        }
        .sidebar-menu .nav-link {
            color: #adb5bd;
            padding: 10px 20px;
            margin-bottom: 5px;
        }
        .sidebar-menu .nav-link:hover {
            color: #fff;
            background-color: #495057;
        }
        .sidebar-menu .nav-link.active {
            color: #fff;
            background-color: var(--main-color);
        }
        .sidebar-menu .nav-link i {
            margin-right: 10px;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #eee;
            padding: 15px 20px;
            font-weight: bold;
        }
        .stat-card {
            border-left: 4px solid var(--main-color);
        }
        .stat-icon {
            font-size: 2.5rem;
            color: var(--main-color);
        }
        .welcome-area {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .welcome-heading {
            color: var(--main-color);
            margin-bottom: 15px;
        }
        .btn-custom {
            background-color: var(--main-color);
            color: white;
        }
        .btn-custom:hover {
            background-color: var(--main-color-dark);
            color: white;
        }
    </style>
</head>
<body>