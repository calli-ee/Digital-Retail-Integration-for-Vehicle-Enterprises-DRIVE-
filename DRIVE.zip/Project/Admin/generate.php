<?php
require_once "header.php";

// Get admin stats (keeping your existing code)
$stmt = $conn->prepare("SELECT created_at FROM Admins WHERE admin_id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin_data = $result->fetch_assoc();
$created_at = date('F j, Y', strtotime($admin_data['created_at']));
$stmt->close();

// Get all vehicles/products
$result = $conn->query("SELECT * FROM Vehicle");
$vehicles = [];
while ($row = $result->fetch_assoc()) {
    $vehicles[] = $row;
}

// Get recent sales and top customers (keeping your existing code)
$result = $conn->query("SELECT * FROM SalesRevenueByDate ORDER BY sales_date DESC LIMIT 7");
$recent_sales = [];
while ($row = $result->fetch_assoc()) {
    $recent_sales[] = $row;
}

$result = $conn->query("SELECT * FROM UserPurchaseTotals LIMIT 5");
$top_customers = [];
while ($row = $result->fetch_assoc()) {
    $top_customers[] = $row;
}
?>

<?php include "sidebar.php"; ?>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <!-- Welcome Area -->
        <div class="welcome-area">
            <h2 class="welcome-heading">Generate Report, <?php echo htmlspecialchars($username); ?>!</h2>
            <p>This is your admin dashboard. Here you can manage your website content, users, and settings.</p>
        </div>
        
        <!-- Registered Vehicles Table -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card printable-area">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>All Registered Vehicles</span>
                        <button class="btn btn-sm btn-orange" onclick="printPDF('Vehicle Inventory', this)">
                            <i class="fas fa-download"></i> Download PDF
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Brand</th>
                                        <th>Model</th>
                                        <th>Year</th>
                                        <th>Specifications</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($vehicles as $vehicle): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($vehicle['vehicle_id']); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['brand']); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['model']); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['year']); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['specifications']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($vehicles)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No vehicles registered yet</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sales Data Tables -->
        <div class="row mt-4">
            <!-- Recent Sales Card -->
            <div class="col-md-6">
                <div class="card printable-area">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Recent Sales Data</span>
                        <button class="btn btn-sm btn-orange" onclick="printPDF('Recent Sales', this)">
                            <i class="fas fa-download"></i> Download PDF
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Sales</th>
                                        <th>Revenue</th>
                                        <th>Avg. Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_sales as $sale): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($sale['sales_date'])); ?></td>
                                        <td><?php echo number_format($sale['number_of_sales']); ?></td>
                                        <td>$<?php echo number_format($sale['daily_revenue'], 2); ?></td>
                                        <td>$<?php echo number_format($sale['average_sale_price'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($recent_sales)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No recent sales data available</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Top Customers Card -->
            <div class="col-md-6">
                <div class="card printable-area">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Top Customers</span>
                        <button class="btn btn-sm btn-orange" onclick="printPDF('Top Customers', this)">
                            <i class="fas fa-download"></i> Download PDF
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Customer</th>
                                        <th>Email</th>
                                        <th>Total Purchases</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_customers as $customer): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($customer['customer_name']); ?></td>
                                        <td><?php echo htmlspecialchars($customer['user_email']); ?></td>
                                        <td>$<?php echo number_format($customer['total_purchase_amount'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($top_customers)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">No customer data available</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- PDF Printing Script -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<style>
.notification-toast {
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    border: none;
}
.notification-toast .btn-close {
    background: none;
    border: none;
    font-size: 18px;
    opacity: 0.7;
    margin-left: 10px;
    cursor: pointer;
}
.notification-toast .btn-close:hover {
    opacity: 1;
}

/* Orange button styles for PDF download buttons */
.btn-orange {
    background-color: #ffa31a;
    border-color: #ffa31a;
    color: white;
    font-weight: 500;
}

.btn-orange:hover {
    background-color: #e6921a;
    border-color: #e6921a;
    color: white;
}

.btn-orange:focus, .btn-orange.focus {
    box-shadow: 0 0 0 0.2rem rgba(255, 163, 26, 0.5);
    background-color: #e6921a;
    border-color: #e6921a;
    color: white;
}

.btn-orange:active, .btn-orange.active {
    background-color: #cc7a15;
    border-color: #cc7a15;
    color: white;
}

.btn-orange:not(:disabled):not(.disabled):active:focus {
    box-shadow: 0 0 0 0.2rem rgba(255, 163, 26, 0.5);
}

.btn-orange:disabled, .btn-orange.disabled {
    background-color: #ffa31a;
    border-color: #ffa31a;
    opacity: 0.65;
}
</style>
<script>
function printPDF(title, buttonElement) {
    // Show loading state
    const originalContent = buttonElement.innerHTML;
    buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    buttonElement.disabled = true;

    const element = buttonElement.closest('.printable-area');
    const filename = title + ' Report - <?php echo date("Y-m-d"); ?>.pdf';
    
    // Clone the element to avoid modifying the original
    const elementClone = element.cloneNode(true);
    
    // Remove the download button from the clone
    const buttons = elementClone.querySelectorAll('button');
    buttons.forEach(button => button.remove());
    
    // Add some styles for better PDF output
    const style = document.createElement('style');
    style.innerHTML = `
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background-color: #f8f9fa; text-align: left; padding: 8px; border: 1px solid #dee2e6; }
        td { padding: 8px; border: 1px solid #dee2e6; }
        .card-header { font-weight: bold; margin-bottom: 10px; }
    `;
    elementClone.prepend(style);
    
    const opt = {
        margin: 10,
        filename: filename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
            scale: 2,
            logging: true,
            useCORS: true,
            allowTaint: true,
            scrollX: 0,
            scrollY: 0
        },
        jsPDF: { 
            unit: 'mm', 
            format: 'a4', 
            orientation: 'portrait'
        }
    };

    // Create and download PDF
    html2pdf().set(opt).from(elementClone).save().then(() => {
        // Success feedback
        buttonElement.innerHTML = '<i class="fas fa-check"></i> Downloaded!';
        
        // Show success message
        showNotification('PDF downloaded successfully!', 'success');
        
        // Reset button after delay
        setTimeout(() => {
            buttonElement.innerHTML = originalContent;
            buttonElement.disabled = false;
        }, 3000);
    }).catch((error) => {
        // Error handling
        console.error('PDF generation failed:', error);
        buttonElement.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Failed';
        
        // Show error message
        showNotification('PDF download failed. Please try again.', 'error');
        
        // Reset button after delay
        setTimeout(() => {
            buttonElement.innerHTML = originalContent;
            buttonElement.disabled = false;
        }, 3000);
    });
}

function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} notification-toast`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
        <button type="button" class="btn-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}
</script>

<?php require_once "footer.php"; ?>