<?php
// Process inventory operations (Add, Edit, Delete, Get)
require_once '../db-connection.php';
$db = new Database();
$conn = $db->conn;

// Function to sanitize input data
function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

// Set header to return JSON
header('Content-Type: application/json');

// Process based on the action parameter
if (isset($_POST['action'])) {
    $action = $_POST['action'];
    
    switch ($action) {
        case 'add':
            // Validate required fields
            if (empty($_POST['vehicle_id']) || empty($_POST['price']) || empty($_POST['quantity']) || empty($_POST['status'])) {
                echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
                exit;
            }
            
            // Sanitize inputs
            $vehicleId = intval($_POST['vehicle_id']);
            $price = floatval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            $status = sanitize($conn, $_POST['status']);
            
            // Validate inputs
            if ($price <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'Please enter a valid price greater than 0.']);
                exit;
            }
            
            if ($quantity < 0) {
                echo json_encode(['status' => 'error', 'message' => 'Quantity cannot be negative.']);
                exit;
            }
            
            // Check if the vehicle exists
            $checkVehicleQuery = "SELECT vehicle_id FROM Vehicle WHERE vehicle_id = ?";
            $checkVehicleStmt = $conn->prepare($checkVehicleQuery);
            $checkVehicleStmt->bind_param("i", $vehicleId);
            $checkVehicleStmt->execute();
            $checkVehicleResult = $checkVehicleStmt->get_result();
            
            if ($checkVehicleResult->num_rows === 0) {
                echo json_encode(['status' => 'error', 'message' => 'The selected vehicle does not exist.']);
                exit;
            }
            
            // Check if this vehicle already exists in inventory (for ADD only)
            $checkExistingQuery = "SELECT inventory_id FROM VehicleInventory WHERE vehicle_id = ?";
            $checkExistingStmt = $conn->prepare($checkExistingQuery);
            $checkExistingStmt->bind_param("i", $vehicleId);
            $checkExistingStmt->execute();
            $checkExistingResult = $checkExistingStmt->get_result();

            if ($checkExistingResult->num_rows > 0) {
                echo json_encode(['status' => 'error', 'message' => 'This vehicle already exists in inventory. Please edit the existing entry instead.']);
                exit;
            }
            
            // Auto-set status to 'sold out' if quantity is 0
            if ($quantity == 0) {
                $status = 'sold out';
            }
            
            // Insert inventory data
            $query = "INSERT INTO VehicleInventory (vehicle_id, price, quantity, status) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("idis", $vehicleId, $price, $quantity, $status);
            
            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Inventory item added successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error adding inventory item: ' . $stmt->error]);
            }
            break;
            
        case 'edit':
            // Validate required fields
            if (empty($_POST['inventory_id']) || empty($_POST['vehicle_id']) || !isset($_POST['price']) || !isset($_POST['quantity']) || empty($_POST['status'])) {
                echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
                exit;
            }
            
            // Sanitize inputs
            $inventoryId = intval($_POST['inventory_id']);
            $vehicleId = intval($_POST['vehicle_id']);
            $price = floatval($_POST['price']);
            $quantity = intval($_POST['quantity']);
            $status = sanitize($conn, $_POST['status']);
            
            // Validate inputs
            if ($price <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'Please enter a valid price greater than 0.']);
                exit;
            }
            
            if ($quantity < 0) {
                echo json_encode(['status' => 'error', 'message' => 'Quantity cannot be negative.']);
                exit;
            }
            
            // Check if the inventory item exists
            $checkInventoryQuery = "SELECT vehicle_id FROM VehicleInventory WHERE inventory_id = ?";
            $checkInventoryStmt = $conn->prepare($checkInventoryQuery);
            $checkInventoryStmt->bind_param("i", $inventoryId);
            $checkInventoryStmt->execute();
            $checkInventoryResult = $checkInventoryStmt->get_result();
            
            if ($checkInventoryResult->num_rows === 0) {
                echo json_encode(['status' => 'error', 'message' => 'Inventory item not found.']);
                exit;
            }
            
            $currentData = $checkInventoryResult->fetch_assoc();
            $currentVehicleId = $currentData['vehicle_id'];
            
            // Only check for duplicate vehicle if the vehicle_id is being changed
            if ($vehicleId != $currentVehicleId) {
                $checkExistingQuery = "SELECT inventory_id FROM VehicleInventory WHERE vehicle_id = ? AND inventory_id != ?";
                $checkExistingStmt = $conn->prepare($checkExistingQuery);
                $checkExistingStmt->bind_param("ii", $vehicleId, $inventoryId);
                $checkExistingStmt->execute();
                $checkExistingResult = $checkExistingStmt->get_result();

                if ($checkExistingResult->num_rows > 0) {
                    echo json_encode(['status' => 'error', 'message' => 'This vehicle already exists in inventory. Please choose a different vehicle.']);
                    exit;
                }
            }
            
            // Check if the new vehicle exists (if vehicle is being changed)
            if ($vehicleId != $currentVehicleId) {
                $checkVehicleQuery = "SELECT vehicle_id FROM Vehicle WHERE vehicle_id = ?";
                $checkVehicleStmt = $conn->prepare($checkVehicleQuery);
                $checkVehicleStmt->bind_param("i", $vehicleId);
                $checkVehicleStmt->execute();
                $checkVehicleResult = $checkVehicleStmt->get_result();
                
                if ($checkVehicleResult->num_rows === 0) {
                    echo json_encode(['status' => 'error', 'message' => 'The selected vehicle does not exist.']);
                    exit;
                }
            }
            
            // Auto-set status to 'sold out' if quantity is 0
            if ($quantity == 0) {
                $status = 'sold out';
            }
            
            // Set current timestamp for last_updated field
            $currentTimestamp = date('Y-m-d H:i:s');
            
            // Update inventory information with last_updated timestamp
            $query = "UPDATE VehicleInventory SET vehicle_id = ?, price = ?, quantity = ?, status = ?, last_updated = ? WHERE inventory_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("idissi", $vehicleId, $price, $quantity, $status, $currentTimestamp, $inventoryId);
            
            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Inventory item updated successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error updating inventory item: ' . $stmt->error]);
            }
            break;
            
        case 'delete':
            // Validate inventory ID
            if (empty($_POST['inventory_id'])) {
                echo json_encode(['status' => 'error', 'message' => 'Inventory ID is required.']);
                exit;
            }
            
            $inventoryId = intval($_POST['inventory_id']);
            
            // Delete the inventory record
            $query = "DELETE FROM VehicleInventory WHERE inventory_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $inventoryId);
            
            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Inventory item deleted successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error deleting inventory item: ' . $stmt->error]);
            }
            break;
            
        case 'get':
            // Validate inventory ID
            if (empty($_POST['inventory_id'])) {
                echo json_encode(['status' => 'error', 'message' => 'Inventory ID is required.']);
                exit;
            }
            
            $inventoryId = intval($_POST['inventory_id']);
            
            // Get inventory details
            $query = "SELECT * FROM VehicleInventory WHERE inventory_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $inventoryId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                echo json_encode(['status' => 'success', 'data' => $row]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Inventory item not found.']);
            }
            break;
            
        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Action parameter is required.']);
}
?>