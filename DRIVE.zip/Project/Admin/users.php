<?php require_once "header.php"; ?>
<?php include "sidebar.php"; ?>

<?php
// Database connection
require_once '../db-connection.php';

// Handle Add User
if (isset($_POST['add_user'])) {
    $full_name = $conn->real_escape_string($_POST['full_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $sql = "INSERT INTO Users (full_name, email, phone, password_hash) 
            VALUES ('$full_name', '$email', '$phone', '$password')";
    
    if ($conn->query($sql) === TRUE) {
        $success_message = "User added successfully";
    } else {
        $error_message = "Error: " . $conn->error;
    }
}

// Handle Edit User
if (isset($_POST['edit_user'])) {
    $user_id = $conn->real_escape_string($_POST['user_id']);
    $full_name = $conn->real_escape_string($_POST['full_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    
    // Check if password is being updated
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "UPDATE Users SET 
                full_name = '$full_name',
                email = '$email',
                phone = '$phone',
                password_hash = '$password'
                WHERE user_id = $user_id";
    } else {
        $sql = "UPDATE Users SET 
                full_name = '$full_name',
                email = '$email',
                phone = '$phone'
                WHERE user_id = $user_id";
    }
    
    if ($conn->query($sql) === TRUE) {
        $success_message = "User updated successfully";
    } else {
        $error_message = "Error: " . $conn->error;
    }
}

// Handle Delete User
if (isset($_POST['delete_user'])) {
    $user_id = $conn->real_escape_string($_POST['user_id']);
    
    // First check if user has any orders
    $check_orders_sql = "SELECT COUNT(*) as order_count FROM Orders WHERE user_id = $user_id";
    $check_result = $conn->query($check_orders_sql);
    
    if ($check_result) {
        $order_data = $check_result->fetch_assoc();
        
        if ($order_data['order_count'] > 0) {
            // User has orders, cannot delete
            $error_message = "Cannot delete user: This user has " . $order_data['order_count'] . " order(s) associated with their account. Users with existing orders cannot be deleted.";
        } else {
            // User has no orders, safe to delete
            $sql = "DELETE FROM Users WHERE user_id = $user_id";
            
            if ($conn->query($sql) === TRUE) {
                $success_message = "User deleted successfully";
            } else {
                $error_message = "Error: " . $conn->error;
            }
        }
    } else {
        $error_message = "Error checking user orders: " . $conn->error;
    }
}

// Fetch all users with order count
$sql = "SELECT u.*, 
        (SELECT COUNT(*) FROM Orders o WHERE o.user_id = u.user_id) as order_count 
        FROM Users u 
        ORDER BY u.created_at DESC";
$result = $conn->query($sql);
?>

<!-- Custom CSS for the orange color theme -->
<style>
    .btn-primary {
        background-color: #ffa31a !important;
        border-color: #ffa31a !important;
    }
    .btn-primary:hover, .btn-primary:focus, .btn-primary:active {
        background-color: #e69200 !important;
        border-color: #e69200 !important;
    }
    .btn-info {
        background-color: #ffa31a !important;
        border-color: #ffa31a !important;
    }
    .btn-info:hover, .btn-info:focus, .btn-info:active {
        background-color: #e69200 !important;
        border-color: #e69200 !important;
    }
    .card-header {
        background-color: #fff8e6 !important;
        border-bottom: 2px solid #ffa31a !important;
    }
    .modal-header {
        background-color: #fff8e6 !important;
        border-bottom: 2px solid #ffa31a !important;
    }
    .page-item.active .page-link {
        background-color: #ffa31a !important;
        border-color: #ffa31a !important;
    }
    .page-link {
        color: #ffa31a !important;
    }
    .page-link:hover {
        color: #e69200 !important;
    }
    
    /* Hide DataTables info and length changing sections */
    .dataTables_info, .dataTables_length {
        display: none !important;
    }
    
    .password-help {
        font-size: 0.875em;
        color: #6c757d;
    }

    /* Style for users with orders - show warning */
    .has-orders {
        background-color: #fff3cd !important;
    }
    
    .order-count-badge {
        font-size: 0.75em;
        margin-left: 5px;
    }

    /* FIXED PAGINATION STYLES */
    /* Reset and clean up pagination wrapper */
    .dataTables_wrapper .dataTables_paginate {
        padding-top: 0.5em;
        text-align: right;
    }

    /* Clean base styles for pagination buttons */
    .dataTables_wrapper .dataTables_paginate .paginate_button {
        box-sizing: border-box !important;
        display: inline-block !important;
        min-width: 1.5em !important;
        padding: 0.5em 1em !important;
        margin-left: 2px !important;
        text-align: center !important;
        text-decoration: none !important;
        cursor: pointer !important;
        color: #333 !important;
        border: 1px solid #ddd !important;
        border-radius: 4px !important;
        background: #fff !important;
        transition: all 0.3s ease !important;
        /* Remove any nested styling conflicts */
        position: relative !important;
    }

    /* Remove inner anchor styling that causes double boxes */
    .dataTables_wrapper .dataTables_paginate .paginate_button a {
        color: inherit !important;
        text-decoration: none !important;
        display: block !important;
        padding: 0 !important;
        margin: 0 !important;
        border: none !important;
        background: transparent !important;
        width: 100% !important;
        height: 100% !important;
    }

    /* Hover state - single clean style */
    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
        color: #fff !important;
        border-color: #ffa31a !important;
        background-color: #ffa31a !important;
        text-decoration: none !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover a {
        color: #fff !important;
        text-decoration: none !important;
    }

    /* Active/Current page button */
    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        color: #fff !important;
        border-color: #ffa31a !important;
        background-color: #ffa31a !important;
        font-weight: bold !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current a {
        color: #fff !important;
        text-decoration: none !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        color: #fff !important;
        border-color: #e69200 !important;
        background-color: #e69200 !important;
    }

    /* Disabled pagination buttons */
    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        cursor: default !important;
        color: #999 !important;
        border-color: #ddd !important;
        background-color: #f9f9f9 !important;
        opacity: 0.5 !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled a {
        color: #999 !important;
        cursor: default !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
        color: #999 !important;
        border-color: #ddd !important;
        background-color: #f9f9f9 !important;
    }

    /* Focus state for accessibility */
    .dataTables_wrapper .dataTables_paginate .paginate_button:focus {
        outline: none !important;
        box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.5) !important;
    }

    /* Ensure Previous/Next buttons look consistent */
    .dataTables_wrapper .dataTables_paginate .paginate_button.previous,
    .dataTables_wrapper .dataTables_paginate .paginate_button.next {
        font-weight: 500;
    }

    /* Enhanced styling for search controls */
    .dataTables_wrapper .dataTables_filter input {
        border: 2px solid #ddd;
        border-radius: 4px;
        padding: 5px 10px;
        transition: border-color 0.3s ease;
    }

    .dataTables_wrapper .dataTables_filter input:focus {
        outline: none;
        border-color: #ffa31a;
        box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.2);
    }
</style>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>User Management</h4>
                        <div class="card-header-action">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">
                                <i class="fa fa-plus"></i> Add New User
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if (isset($success_message)): ?>
                            <div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                    <button class="close" data-dismiss="alert">
                                        <span>×</span>
                                    </button>
                                    <?php echo $success_message; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($error_message)): ?>
                            <div class="alert alert-danger alert-dismissible show fade">
                                <div class="alert-body">
                                    <button class="close" data-dismiss="alert">
                                        <span>×</span>
                                    </button>
                                    <?php echo $error_message; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <div class="table-responsive">
                            <table class="table table-striped" id="usersTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Full Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Orders</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($result && $result->num_rows > 0): ?>
                                        <?php while($row = $result->fetch_assoc()): ?>
                                            <tr <?php echo ($row['order_count'] > 0) ? 'class="has-orders"' : ''; ?>>
                                                <td><?php echo $row['user_id']; ?></td>
                                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                                <td>
                                                    <?php if ($row['order_count'] > 0): ?>
                                                        <span class="badge badge-warning order-count-badge">
                                                            <?php echo $row['order_count']; ?> order(s)
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary order-count-badge">
                                                            No orders
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $row['created_at']; ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-info btn-sm edit-btn" 
                                                            data-id="<?php echo $row['user_id']; ?>"
                                                            data-name="<?php echo htmlspecialchars($row['full_name']); ?>"
                                                            data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                                            data-phone="<?php echo htmlspecialchars($row['phone']); ?>">
                                                        <i class="fas fa-edit"></i> Edit
                                                    </button>
                                                    <button type="button" class="btn btn-danger btn-sm delete-btn"
                                                            data-id="<?php echo $row['user_id']; ?>"
                                                            data-name="<?php echo htmlspecialchars($row['full_name']); ?>"
                                                            data-orders="<?php echo $row['order_count']; ?>">
                                                        <i class="fas fa-trash"></i> Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7" class="text-center">No users found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" id="addUserForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="add_user" class="btn btn-primary">Save User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" id="editUserForm">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="edit_full_name">Full Name</label>
                        <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_email">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_phone">Phone</label>
                        <input type="text" class="form-control" id="edit_phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="edit_password">New Password</label>
                        <input type="password" class="form-control" id="edit_password" name="password">
                        <small class="password-help">Leave blank to keep current password</small>
                    </div>
                    <div class="form-group">
                        <label for="edit_confirm_password">Confirm New Password</label>
                        <input type="password" class="form-control" id="edit_confirm_password" name="confirm_password">
                        <small class="password-help">Only required if changing password</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="edit_user" class="btn btn-primary">Update User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserModalLabel">Delete User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="" method="POST" id="deleteUserForm">
                <div class="modal-body">
                    <input type="hidden" name="user_id" id="delete_user_id">
                    <p>Are you sure you want to delete user <strong id="delete_user_name"></strong>?</p>
                    <p class="text-danger">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_user" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Warning Modal for Users with Orders -->
<div class="modal fade" id="warningModal" tabindex="-1" role="dialog" aria-labelledby="warningModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title" id="warningModalLabel">
                    <i class="fas fa-exclamation-triangle"></i> Cannot Delete User
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning" role="alert">
                    <h6><strong>User cannot be deleted!</strong></h6>
                    <p class="mb-2">The user <strong id="warning_user_name"></strong> has <strong id="warning_order_count"></strong> order(s) associated with their account.</p>
                    <p class="mb-0">Only users with no orders can be deleted. This restriction is in place to maintain data integrity and order history.</p>
                </div>
                <h6>Alternative options:</h6>
                <ul class="mb-0">
                    <li>You can edit the user's information if needed</li>
                    <li>Contact system administrator to handle users with existing orders</li>
                    <li>Consider deactivating the user instead of deletion</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- First include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Then include Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- DataTables JS (if you're using it) -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
    // Initialize DataTable with custom options
    $('#usersTable').DataTable({
        // Remove the "Show X entries" dropdown
        lengthChange: false,
        // Remove the "Showing X to Y of Z entries" text
        info: false,
        // Set a fixed page length (you can adjust this value as needed)
        pageLength: 10
    });
    
    // Form validation for add user form
    $('#addUserForm').submit(function(e) {
        var password = $('#password').val();
        var confirmPassword = $('#confirm_password').val();
        
        if (password !== confirmPassword) {
            e.preventDefault();
            alert('Passwords do not match!');
            return false;
        }
    });
    
    // Form validation for edit user form
    $('#editUserForm').submit(function(e) {
        var password = $('#edit_password').val();
        var confirmPassword = $('#edit_confirm_password').val();
        
        // Only validate if password is being changed
        if (password.length > 0 || confirmPassword.length > 0) {
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
        }
    });
    
    // Handle edit button clicks
    $('.edit-btn').on('click', function() {
        var userId = $(this).data('id');
        var name = $(this).data('name');
        var email = $(this).data('email');
        var phone = $(this).data('phone');
        
        $('#edit_user_id').val(userId);
        $('#edit_full_name').val(name);
        $('#edit_email').val(email);
        $('#edit_phone').val(phone);
        
        // Clear password fields
        $('#edit_password').val('');
        $('#edit_confirm_password').val('');
        
        $('#editUserModal').modal('show');
    });
    
    // Handle delete button clicks
    $('.delete-btn').on('click', function() {
        var userId = $(this).data('id');
        var name = $(this).data('name');
        var orderCount = $(this).data('orders');
        
        // Check if user has orders
        if (orderCount > 0) {
            // Show warning modal instead of delete modal
            $('#warning_user_name').text(name);
            $('#warning_order_count').text(orderCount);
            $('#warningModal').modal('show');
        } else {
            // User has no orders, show normal delete confirmation
            $('#delete_user_id').val(userId);
            $('#delete_user_name').text(name);
            $('#deleteUserModal').modal('show');
        }
    });
    
    // Make sure modals can be reopened
    $('.modal').on('hidden.bs.modal', function() {
        $(this).find('form').trigger('reset');
    });
    
    // Check if jQuery and Bootstrap are loaded
    if (typeof jQuery == 'undefined') {
        console.error('jQuery is not loaded! Please check your header.php file.');
    }
    
    if (typeof $.fn.modal == 'undefined') {
        console.error('Bootstrap is not loaded! Please check your header.php file.');
    }
});
</script>