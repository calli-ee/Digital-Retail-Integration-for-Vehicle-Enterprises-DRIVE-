<?php
require_once "header.php";

// Get some admin stats
$stmt = $conn->prepare("SELECT created_at FROM Admins WHERE admin_id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin_data = $result->fetch_assoc();
$created_at = date('F j, Y', strtotime($admin_data['created_at']));
$stmt->close();

// Get total admins
$result = $conn->query("SELECT COUNT(*) as total FROM Admins");
$row = $result->fetch_assoc();
$total_admins = $row['total'];

// Get total users
$result = $conn->query("SELECT COUNT(*) as total FROM Users");
$row = $result->fetch_assoc();
$total_users = $row['total'];

// Get total sales
$result = $conn->query("SELECT SUM(quantity) as total FROM Orders");
$row = $result->fetch_assoc();
$total_sales = $row['total'] ?: 0;

// Get total revenue
$result = $conn->query("SELECT SUM(vi.price * o.quantity) as total FROM Orders o 
                        JOIN Vehicle v ON o.vehicle_id = v.vehicle_id 
                        JOIN VehicleInventory vi ON v.vehicle_id = vi.vehicle_id");
$row = $result->fetch_assoc();
$total_revenue = $row['total'] ?: 0;

// Get recent sales data (last 7 days) for chart
$result = $conn->query("SELECT sales_date, number_of_sales, daily_revenue FROM SalesRevenueByDate ORDER BY sales_date DESC LIMIT 7");
$recent_sales_chart = [];
$sales_labels = [];
$sales_data = [];
$revenue_data = [];

while ($row = $result->fetch_assoc()) {
    $recent_sales_chart[] = $row;
    $sales_labels[] = date('M d', strtotime($row['sales_date']));
    $sales_data[] = $row['number_of_sales'];
    $revenue_data[] = $row['daily_revenue'];
}

// Reverse to show chronological order
$sales_labels = array_reverse($sales_labels);
$sales_data = array_reverse($sales_data);
$revenue_data = array_reverse($revenue_data);

// Get recent sales for table
$result = $conn->query("SELECT * FROM SalesRevenueByDate ORDER BY sales_date DESC LIMIT 5");
$recent_sales = [];
while ($row = $result->fetch_assoc()) {
    $recent_sales[] = $row;
}

// Get top customers
$result = $conn->query("SELECT * FROM UserPurchaseTotals LIMIT 5");
$top_customers = [];
while ($row = $result->fetch_assoc()) {
    $top_customers[] = $row;
}
?>

<?php include "sidebar.php"; ?>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <!-- Welcome Area -->
        <div class="welcome-area">
            <h2 class="welcome-heading">Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
            <p>Your admin account was created on <?php echo $created_at; ?>.</p>
        </div>
        
        <!-- Stats Row - Now with 3 cards instead of 4 -->
        <div class="row">
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-muted">Total Users</h6>
                                <h2 class="mb-0"><?php echo number_format($total_users); ?></h2>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-people"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-muted">Total Sales</h6>
                                <h2 class="mb-0"><?php echo number_format($total_sales); ?></h2>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-cart-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-muted">Total Revenue</h6>
                                <h2 class="mb-0">₱<?php echo number_format($total_revenue, 2); ?></h2>
                            </div>
                            <div class="stat-icon">
                                <i class="bi bi-cash-stack"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Charts Row -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Sales Trend (Last 7 Days)</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="salesChart" height="250"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Revenue Trend (Last 7 Days)</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="revenueChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Data Tables Row -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Recent Sales</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Sales</th>
                                        <th>Revenue</th>
                                        <th>Avg. Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_sales as $sale): ?>
                                    <tr>
                                        <td><?php echo date('M d, Y', strtotime($sale['sales_date'])); ?></td>
                                        <td><?php echo number_format($sale['number_of_sales']); ?></td>
                                        <td>$<?php echo number_format($sale['daily_revenue'], 2); ?></td>
                                        <td>$<?php echo number_format($sale['average_sale_price'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($recent_sales)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No recent sales data available</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Top Customers</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Customer</th>
                                        <th>Email</th>
                                        <th>Total Purchases</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_customers as $customer): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($customer['customer_name']); ?></td>
                                        <td><?php echo htmlspecialchars($customer['user_email']); ?></td>
                                        <td>$<?php echo number_format($customer['total_purchase_amount'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($top_customers)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">No customer data available</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Sales Chart
    const salesCtx = document.getElementById('salesChart').getContext('2d');
    const salesChart = new Chart(salesCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($sales_labels); ?>,
            datasets: [{
                label: 'Number of Sales',
                data: <?php echo json_encode($sales_data); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($sales_labels); ?>,
            datasets: [{
                label: 'Daily Revenue ($)',
                data: <?php echo json_encode($revenue_data); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
</script>

<?php require_once "footer.php"; ?>