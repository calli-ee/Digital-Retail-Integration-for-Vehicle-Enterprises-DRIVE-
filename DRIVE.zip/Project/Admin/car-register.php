<?php 
require_once "header.php";
require_once '../db-connection.php';
include "sidebar.php"; 
$db = new Database();
$conn = $db->conn;
?>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card" style="border-top: 3px solid #ffa31a;">
                    <div class="card-header" style="background-color: #ffa31a; color: white;">
                        <h4>Vehicle Registration System</h4>
                        <button type="button" class="btn btn-light float-right" data-toggle="modal" data-target="#addVehicleModal">
                            <i class="fa fa-plus"></i> Add New Vehicle
                        </button>
                    </div>
                    <div class="card-body">
                        <!-- Message display area for feedback -->
                        <div id="message-area"></div>
                        
                        <!-- Improved Vehicle listing table -->
                     <table class="table table-striped table-hover" id="vehicleTable" style="width:100%">
    <thead style="background-color: #fff5e6;">
        <tr>
            <th width="5%">ID</th>
            <th width="15%">Image</th>
            <th width="15%">Brand</th>
            <th width="15%">Model</th>
            <th width="10%">Year</th>
            <th width="25%">Specifications</th>
            <th width="15%">Actions</th>
        </tr>
    </thead>
    <tbody>
                                    <?php
                                    // Fetch all vehicles from the database
                                    $query = "SELECT * FROM Vehicle ORDER BY vehicle_id DESC";
                                    $result = mysqli_query($conn, $query);
                                    
                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo '<tr>';
                                            echo '<td>' . $row['vehicle_id'] . '</td>';
                                            echo '<td>';
                                            if (!empty($row['image_url'])) {
                                                echo '<img src="' . $row['image_url'] . '" class="img-thumbnail" style="max-width: 100px; height: auto;" alt="Vehicle Image">';
                                            } else {
                                                echo '<img src="assets/img/no-image.png" class="img-thumbnail" style="max-width: 100px; height: auto;" alt="No Image">';
                                            }
                                            echo '</td>';
                                            echo '<td>' . htmlspecialchars($row['brand']) . '</td>';
                                            echo '<td>' . htmlspecialchars($row['model']) . '</td>';
                                            echo '<td>' . $row['year'] . '</td>';
                                            echo '<td style="word-wrap: break-word; max-width: 300px;">' . htmlspecialchars($row['specifications']) . '</td>';
                                            echo '<td>';
                                            echo '<button class="btn btn-sm btn-orange edit-btn" data-id="' . $row['vehicle_id'] . '"><i class="fa fa-edit"></i> Edit</button> ';
                                            echo '<button class="btn btn-sm btn-danger delete-btn" data-id="' . $row['vehicle_id'] . '"><i class="fa fa-trash"></i> Delete</button>';
                                            echo '</td>';
                                            echo '</tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="7" class="text-center">No vehicles registered yet.</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Vehicle Modal -->
<div class="modal fade" id="addVehicleModal" tabindex="-1" role="dialog" aria-labelledby="addVehicleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #ffa31a; color: white;">
                <h5 class="modal-title" id="addVehicleModalLabel">Add New Vehicle</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="addVehicleForm" action="process-vehicle.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="brand">Brand</label>
                        <input type="text" class="form-control" id="brand" name="brand" required>
                    </div>
                    <div class="form-group">
                        <label for="model">Model</label>
                        <input type="text" class="form-control" id="model" name="model" required>
                    </div>
                    <div class="form-group">
                        <label for="year">Year</label>
                        <input type="number" class="form-control" id="year" name="year" min="1900" max="2099" required>
                    </div>
                    <div class="form-group">
                        <label for="specifications">Specifications</label>
                        <textarea class="form-control" id="specifications" name="specifications" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="vehicleImage">Vehicle Image</label>
                        <input type="file" class="form-control-file" id="vehicleImage" name="vehicleImage" accept="image/*" require>
                        <small class="form-text text-muted">Upload an image of the vehicle</small>
                    </div>
                    <input type="hidden" name="action" value="add">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" style="background-color: #ffa31a; border-color: #ffa31a;">Save Vehicle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Vehicle Modal -->
<div class="modal fade" id="editVehicleModal" tabindex="-1" role="dialog" aria-labelledby="editVehicleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #ffa31a; color: white;">
                <h5 class="modal-title" id="editVehicleModalLabel">Edit Vehicle</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editVehicleForm" action="process-vehicle.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="editBrand">Brand</label>
                        <input type="text" class="form-control" id="editBrand" name="brand" required>
                    </div>
                    <div class="form-group">
                        <label for="editModel">Model</label>
                        <input type="text" class="form-control" id="editModel" name="model" required>
                    </div>
                    <div class="form-group">
                        <label for="editYear">Year</label>
                        <input type="number" class="form-control" id="editYear" name="year" min="1900" max="2099" required>
                    </div>
                    <div class="form-group">
                        <label for="editSpecifications">Specifications</label>
                        <textarea class="form-control" id="editSpecifications" name="specifications" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="editVehicleImage">Vehicle Image</label>
                        <input type="file" class="form-control-file" id="editVehicleImage" name="vehicleImage" accept="image/*">
                        <small class="form-text text-muted">Upload a new image (leave empty to keep current image)</small>
                        <div id="currentImageContainer" class="mt-2"></div>
                    </div>
                    <input type="hidden" id="editVehicleId" name="vehicle_id">
                    <input type="hidden" name="action" value="edit">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" style="background-color: #ffa31a; border-color: #ffa31a;">Update Vehicle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteVehicleModal" tabindex="-1" role="dialog" aria-labelledby="deleteVehicleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteVehicleModalLabel">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this vehicle? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" id="confirmDelete" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
</div>

<!-- Enhanced CSS for Orange Button -->
<style>
.btn-orange {
    background-color: #ffa31a;
    border-color: #ffa31a;
    color: white;
    font-weight: 500;
}

.btn-orange:hover {
    background-color: #e6921a;
    border-color: #e6921a;
    color: white;
}

.btn-orange:focus, .btn-orange.focus {
    box-shadow: 0 0 0 0.2rem rgba(255, 163, 26, 0.5);
    background-color: #e6921a;
    border-color: #e6921a;
    color: white;
}

.btn-orange:active, .btn-orange.active {
    background-color: #cc7a15;
    border-color: #cc7a15;
    color: white;
}

.btn-orange:not(:disabled):not(.disabled):active:focus {
    box-shadow: 0 0 0 0.2rem rgba(255, 163, 26, 0.5);
}

/* ADD THE NEW PAGINATION STYLES HERE */
/* FIXED PAGINATION STYLES - Replace the existing pagination CSS with this */

/* Reset and clean up pagination wrapper */
.dataTables_wrapper .dataTables_paginate {
    padding-top: 0.5em;
    text-align: right;
}

/* Clean base styles for pagination buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button {
    box-sizing: border-box !important;
    display: inline-block !important;
    min-width: 1.5em !important;
    padding: 0.5em 1em !important;
    margin-left: 2px !important;
    text-align: center !important;
    text-decoration: none !important;
    cursor: pointer !important;
    color: #333 !important;
    border: 1px solid #ddd !important;
    border-radius: 4px !important;
    background: #fff !important;
    transition: all 0.3s ease !important;
    /* Remove any nested styling conflicts */
    position: relative !important;
}

/* Remove inner anchor styling that causes double boxes */
.dataTables_wrapper .dataTables_paginate .paginate_button a {
    color: inherit !important;
    text-decoration: none !important;
    display: block !important;
    padding: 0 !important;
    margin: 0 !important;
    border: none !important;
    background: transparent !important;
    width: 100% !important;
    height: 100% !important;
}

/* Hover state - single clean style */
.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    color: #fff !important;
    border-color: #ffa31a !important;
    background-color: #ffa31a !important;
    text-decoration: none !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover a {
    color: #fff !important;
    text-decoration: none !important;
}

/* Active/Current page button */
.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    color: #fff !important;
    border-color: #ffa31a !important;
    background-color: #ffa31a !important;
    font-weight: bold !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current a {
    color: #fff !important;
    text-decoration: none !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
    color: #fff !important;
    border-color: #e6921a !important;
    background-color: #e6921a !important;
}

/* Disabled pagination buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
    cursor: default !important;
    color: #999 !important;
    border-color: #ddd !important;
    background-color: #f9f9f9 !important;
    opacity: 0.5 !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.disabled a {
    color: #999 !important;
    cursor: default !important;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.disabled:hover {
    color: #999 !important;
    border-color: #ddd !important;
    background-color: #f9f9f9 !important;
}

/* Focus state for accessibility */
.dataTables_wrapper .dataTables_paginate .paginate_button:focus {
    outline: none !important;
    box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.5) !important;
}

/* Ensure Previous/Next buttons look consistent */
.dataTables_wrapper .dataTables_paginate .paginate_button.previous,
.dataTables_wrapper .dataTables_paginate .paginate_button.next {
    font-weight: 500;
}

/* Optional: Enhanced styling for search and length controls */
.dataTables_wrapper .dataTables_filter input {
    border: 2px solid #ddd;
    border-radius: 4px;
    padding: 5px 10px;
    transition: border-color 0.3s ease;
}

.dataTables_wrapper .dataTables_filter input:focus {
    outline: none;
    border-color: #ffa31a;
    box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.2);
}

.dataTables_wrapper .dataTables_length select {
    border: 2px solid #ddd;
    border-radius: 4px;
    padding: 3px 8px;
    transition: border-color 0.3s ease;
}

.dataTables_wrapper .dataTables_length select:focus {
    outline: none;
    border-color: #ffa31a;
    box-shadow: 0 0 0 2px rgba(255, 163, 26, 0.2);
}
</style>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
    // Initialize DataTable with AJAX
    var table = $('#vehicleTable').DataTable({
        "responsive": true,
        "autoWidth": false,
        "ajax": {
            "url": "process-vehicle.php?action=get_vehicles",
            "type": "GET",
            "dataSrc": "data"
        },
        "columns": [
            { "data": "vehicle_id" },
            { "data": "image" },
            { "data": "brand" },
            { "data": "model" },
            { "data": "year" },
            { "data": "specifications" },
            { 
                "data": "actions",
                "orderable": false,
                "searchable": false
            }
        ],
        "columnDefs": [
            { "width": "5%", "targets": 0 },
            { "width": "15%", "targets": 1 },
            { "width": "15%", "targets": 2 },
            { "width": "15%", "targets": 3 },
            { "width": "10%", "targets": 4 },
            { "width": "25%", "targets": 5 },
            { "width": "15%", "targets": 6 }
        ]
    });
    
    // Handle edit button click - use event delegation since rows are dynamic
    $('#vehicleTable').on('click', '.edit-btn', function() {
        var vehicleId = $(this).data('id');
        
        $.ajax({
            url: 'process-vehicle.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'get',
                vehicle_id: vehicleId
            },
            success: function(response) {
                if (response.status === 'success') {
                    var vehicle = response.data;
                    
                    $('#editVehicleId').val(vehicle.vehicle_id);
                    $('#editBrand').val(vehicle.brand);
                    $('#editModel').val(vehicle.model);
                    $('#editYear').val(vehicle.year);
                    $('#editSpecifications').val(vehicle.specifications);
                    
                    if (vehicle.image_url) {
                        $('#currentImageContainer').html('<img src="' + vehicle.image_url + '" class="img-thumbnail" style="max-width: 150px; height: auto;" alt="Current Image">');
                    } else {
                        $('#currentImageContainer').html('<p>No image available</p>');
                    }
                    
                    $('#editVehicleModal').modal('show');
                } else {
                    showMessage('Error loading vehicle data: ' + response.message, 'danger');
                }
            },
            error: function() {
                showMessage('Server error occurred while fetching vehicle data.', 'danger');
            }
        });
    });
    
    // Handle delete button click
    var deleteVehicleId;
    $('#vehicleTable').on('click', '.delete-btn', function() {
        deleteVehicleId = $(this).data('id');
        $('#deleteVehicleModal').modal('show');
    });
    
    // Handle delete confirmation
    $('#confirmDelete').click(function() {
        $.ajax({
            url: 'process-vehicle.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'delete',
                vehicle_id: deleteVehicleId
            },
            success: function(response) {
                if (response.status === 'success') {
                    $('#deleteVehicleModal').modal('hide');
                    showMessage(response.message, 'success');
                    table.ajax.reload(); // Reload the table data
                } else {
                    $('#deleteVehicleModal').modal('hide');
                    showMessage(response.message, 'danger');
                }
            },
            error: function() {
                $('#deleteVehicleModal').modal('hide');
                showMessage('Server error occurred during deletion.', 'danger');
            }
        });
    });
    
    // Form submission via AJAX for add form
    $('#addVehicleForm').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    $('#addVehicleModal').modal('hide');
                    $('#addVehicleForm')[0].reset();
                    showMessage(response.message, 'success');
                    table.ajax.reload(); // Reload the table data
                } else {
                    showMessage(response.message, 'danger');
                }
            },
            error: function() {
                showMessage('Server error occurred while adding the vehicle.', 'danger');
            }
        });
    });
    
    // Form submission via AJAX for edit form
    $('#editVehicleForm').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    $('#editVehicleModal').modal('hide');
                    showMessage(response.message, 'success');
                    table.ajax.reload(); // Reload the table data
                } else {
                    showMessage(response.message, 'danger');
                }
            },
            error: function() {
                showMessage('Server error occurred while updating the vehicle.', 'danger');
            }
        });
    });
    
    // Helper function to show messages
    function showMessage(message, type) {
        $('#message-area').html('<div class="alert alert-' + type + ' alert-dismissible fade show">' + 
            message + 
            '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
            '<span aria-hidden="true">&times;</span>' +
            '</button></div>');
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $('.alert').alert('close');
        }, 5000);
    }
});
</script>