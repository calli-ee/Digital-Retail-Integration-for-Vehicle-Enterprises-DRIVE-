<?php
// Create a sidebar.php file with this content
$db = new Database();
$conn = $db->conn;
// Check if user is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Get current page for highlighting active link
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3>Admin Panel</h3>
    </div>
    <div class="sidebar-menu">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>" href="users.php">
                    <i class="bi bi-people"></i> Users
                </a>
            </li>
          <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'car-register.php') ? 'active' : ''; ?>" href="car-register.php">
                    <i class="bi bi-car-front"></i> Car Register
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'car-inventory.php') ? 'active' : ''; ?>" href="car-inventory.php">
                    <i class="bi bi-clipboard-data"></i> Car Inventory
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>" href="orders.php">
                   <i class="bi bi-cart"></i>Orders
                </a>
            </li>
           <li class="nav-item">
    <a class="nav-link <?php echo ($current_page == 'generate.php') ? 'active' : ''; ?>" href="generate.php">
        <i class="bi bi-bar-chart me-2"></i> Generate Report
    </a>
</li>
        </ul>
        
        <!-- Logout at bottom -->
        <div class="sidebar-logout">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="logoutadmin.php">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>