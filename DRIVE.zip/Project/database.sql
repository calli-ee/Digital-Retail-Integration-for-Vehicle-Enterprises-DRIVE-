CREATE DATABASE DriveFinal;
USE DriveFinal;


-- Admin Table
ALTER TABLE VehicleInventory ADD COLUMN last_updated DATETIME NULL;
SELECT * FROM Admins;


-- Users Table (unchanged)
CREATE TABLE Admins (
	admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE Vehicle (
    vehicle_id INT PRIMARY KEY AUTO_INCREMENT,
    brand VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    image_url VARCHAR(255),
    specifications TEXT
);
SELECT * FROM Vehicle;
DELETE FROM Vehicle WHERE vehicle_id = 3;

CREATE TABLE VehicleInventory (
    inventory_id INT PRIMARY KEY AUTO_INCREMENT,
    vehicle_id INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT DEFAULT 1,
    status ENUM('available', 'sold out', 'reserved') DEFAULT 'available',
    date_added DATE DEFAULT CURRENT_DATE,
	last_updated DATETIME NULL,
    FOREIGN KEY (vehicle_id) REFERENCES Vehicle(vehicle_id)
);


CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    vehicle_id INT NOT NULL,
    quantity INT NOT NULL,
    address TEXT NOT NULL,
    receipt_image VARCHAR(255),
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (vehicle_id) REFERENCES Vehicle(vehicle_id),
	admin_notes TEXT,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);


CREATE VIEW UserPurchaseTotals AS
SELECT 
    u.email AS user_email,
    u.full_name AS customer_name,
    SUM(vi.price * o.quantity) AS total_purchase_amount
FROM Orders o
JOIN Users u ON o.user_id = u.user_id
JOIN Vehicle v ON o.vehicle_id = v.vehicle_id
JOIN VehicleInventory vi ON v.vehicle_id = vi.vehicle_id
GROUP BY u.user_id, u.email, u.full_name
ORDER BY total_purchase_amount DESC;


CREATE VIEW SalesRevenueByDate AS
SELECT 
    DATE(o.order_date) AS sales_date,
    COUNT(o.order_id) AS number_of_sales,
    SUM(vi.price * o.quantity) AS daily_revenue,
    AVG(vi.price) AS average_sale_price
FROM Orders o
JOIN Vehicle v ON o.vehicle_id = v.vehicle_id
JOIN VehicleInventory vi ON v.vehicle_id = vi.vehicle_id
GROUP BY DATE(o.order_date)
