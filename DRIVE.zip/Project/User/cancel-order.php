<?php
session_start();
require_once '../db-connection.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new Database();
    $conn = $db->conn;

    $order_id = $conn->real_escape_string($_POST['order_id']);
    $cancel_reason = $conn->real_escape_string($_POST['cancel_reason']);
    $user_id = $_SESSION['user_id'];

    // Verify the order belongs to the user
    $check_sql = "SELECT * FROM Orders WHERE order_id = '$order_id' AND user_id = '$user_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows === 0) {
        $_SESSION['error'] = "Order not found or you don't have permission to cancel this order";
        header('Location: orders.php');
        exit;
    }

    $order = $check_result->fetch_assoc();

    // Check if order can be cancelled (only pending or processing)
    if ($order['status'] !== 'pending' && $order['status'] !== 'processing') {
        $_SESSION['error'] = "This order cannot be cancelled as it has already been " . $order['status'];
        header('Location: orders.php');
        exit;
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Update order status
        $update_sql = "UPDATE Orders SET status = 'cancelled', admin_notes = CONCAT(IFNULL(admin_notes, ''), '\nCancellation Reason: $cancel_reason') WHERE order_id = '$order_id'";
        $conn->query($update_sql);

        // Restore inventory if needed
        $restore_sql = "UPDATE VehicleInventory vi
                       JOIN Orders o ON vi.vehicle_id = o.vehicle_id
                       SET vi.quantity = vi.quantity + o.quantity,
                           vi.status = CASE 
                               WHEN vi.status = 'sold out' THEN 'available'
                               ELSE vi.status
                           END
                       WHERE o.order_id = '$order_id'";
        $conn->query($restore_sql);

        $conn->commit();

        $_SESSION['success'] = "Order #$order_id has been cancelled successfully";
        header('Location: orders.php');
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = "Error cancelling order: " . $e->getMessage();
        header('Location: orders.php');
        exit;
    }
} else {
    header('Location: orders.php');
    exit;
}