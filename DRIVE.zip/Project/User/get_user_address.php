<?php
session_start();
require_once '../db-connection.php';

header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    echo json_encode(['error' => 'Not logged in']);
    exit;
}

$userId = $_SESSION['user_id'];
$db = new Database();
$conn = $db->conn;

$sql = "SELECT address FROM Users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(['address' => $row['address']]);
} else {
    echo json_encode(['address' => null]);
}

$stmt->close();
$conn->close();
?>