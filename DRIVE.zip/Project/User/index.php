<?php
session_start();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>DRIVE</title>
    <link rel="icon" type="image/x-icon" href="/Project/sign.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DRIVE - Vehicle Enterprises</title>
    <link rel="stylesheet" href="Style/styles.css">
</head>
<style>.user-menu {
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-account {
    display: flex;
    align-items: center;
    color: #ffa31a;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s;
}


.user-account:before {
    content: '👤';
    margin-right: 5px;
    font-size: 1.2rem;
}
</style>
<body>
    <!-- Header and Navigation -->
    <header>
        <nav class="navbar">
            <a href="#" class="logo">DRIVE</a>
            <ul class="nav-menu">
                <li class="nav-item"><a href="#" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="#about" class="nav-link">About Us</a></li>
                <li class="nav-item"><a href="browseInventory.php" class="nav-link">Inventory</a></li>
                <li class="nav-item"><a href="orders.php" class="nav-link">Orders</a></li>
            </ul>
            <div class="nav-right">
                <?php if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <!-- User is logged in -->
                    <div class="user-menu">
                        <a href="account.php" class="user-account">My Account</a>
                        <a href="logout.php" class="auth-btn">Logout</a>
                    </div>
                <?php else: ?>
                    <!-- User is not logged in -->
                    <div class="auth-buttons">
                        <a href="login.php" class="auth-btn" id="loginBtn">Login</a>
                        <a href="signup.php" class="auth-btn primary" id="signupBtn">Sign Up</a>
                    </div>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <h1>DRIVE - Vehicle Enterprises</h1>
        <p>Modern automotive solutions with streamlined inventory management and enhanced customer experience.</p>
        <a href="#inventory" class="btn">Browse Inventory</a>
    </section>

    <!-- About Us Section -->
    <section id="about" class="features">
        <h2 class="section-title">About DRIVE</h2>
        <div class="about-content">
            <p class="about-intro">Welcome to DRIVE Vehicle Enterprises, your premier destination for quality vehicles at competitive prices. Since our establishment, we have been dedicated to providing exceptional automotive experiences for our customers.</p>
            
            <div class="feature-cards">
                <div class="feature-card">
                    <div class="feature-icon">🚗</div>
                    <h3>Premium Selection</h3>
                    <p>We offer a diverse range of vehicles from economy to luxury, ensuring there's something for every budget and preference.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💰</div>
                    <h3>Competitive Pricing</h3>
                    <p>Our transparent pricing policy ensures you get the best value for your investment with no hidden costs.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🛠️</div>
                    <h3>Expert Service</h3>
                    <p>Our certified technicians provide comprehensive maintenance and repair services to keep your vehicle in optimal condition.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🤝</div>
                    <h3>Customer Satisfaction</h3>
                    <p>With our customer-first approach, we ensure a hassle-free buying experience and ongoing support after purchase.</p>
                </div>
            </div>
        </div>
    </section>

   <section id="inventory" class="inventory">
        <h2 class="section-title">Browse Our Inventory</h2>
        <div class="car-grid">
            <!-- Car 1 -->
            <div class="car-card">
                <img src="https://vehicle-images.dealerinspire.com/16ac-110012203/4T1C11BK7RU126968/2ab7d9742ae290c5cbc5c106afeea719.jpg" alt="Car 1" class="car-image">
                <div class="car-details">
                    <h3 class="car-title">2024 Toyota Camry LE</h3>
                    <p class="car-price">₱2,657,000</p>
                    <div class="car-specs">
                        <span>28/39 MPG</span>
                        <span>2.5L 4-Cylinder</span>
                        <span>FWD</span>
                    </div>
                    <a href="browseInventory.php" class="btn" rel="noopener noreferrer">View Details</a>
                </div>
            </div>
            
            <!-- Car 2 -->
            <div class="car-card">
                <img src="https://vehicle-images.dealerinspire.com/9d72-110011724/thumbnails/large/1HGCY2F53SA013988/a964136c4a332bd6abfd24757e681e96.png" alt="Car 2" class="car-image">
                <div class="car-details">
                    <h3 class="car-title">2024 Honda Accord Sport</h3>
                    <p class="car-price">₱2,288,000</p>
                    <div class="car-specs">
                        <span>29/37 MPG</span>
                        <span>1.5L Turbo</span>
                        <span>FWD</span>
                    </div>
                    <a href="browseInventory.php" class="btn" rel="noopener noreferrer">View Details</a>
                </div>
            </div>
            
            <!-- Car 3 -->
            <div class="car-card">
                <img src="https://d2qldpouxvc097.cloudfront.net/image-by-path?bucket=a5-gallery-serverless-prod-chromebucket-1iz9ffi08lwxm&key=439076%2Ffront34%2Flg%2Fe7e7e7" alt="Car 3" class="car-image">
                <div class="car-details">
                    <h3 class="car-title">2024 Ford Mustang GT</h3>
                    <p class="car-price">₱3,999,000</p>
                    <div class="car-specs">
                        <span>15/24 MPG</span>
                        <span>5.0L V8</span>
                        <span>RWD</span>
                    </div>
                    <a href="browseInventory.php" class="btn" rel="noopener noreferrer">View Details</a>
                </div>
            </div>
            
            <!-- Car 4 -->
            <div class="car-card">
                <img src="https://autoimage.capitalone.com/stock-media/chrome/2024-Tesla-Model_3-Base-SGRY-cc_2024TSC030004_01_2100_SGRY.png" alt="Car 4" class="car-image">
                <div class="car-details">
                    <h3 class="car-title">2024 Tesla Model 3</h3>
                    <p class="car-price">₱2,109,000</p>
                    <div class="car-specs">
                        <span>134/126 MPGe</span>
                        <span>Electric</span>
                        <span>RWD</span>
                    </div>
                    <a href="browseInventory.php" class="btn" rel="noopener noreferrer">View Details</a>
                </div>
            </div>
            
            <!-- Car 5 -->
            <div class="car-card">
                <img src="https://medias.fcacanada.ca/jellies/renditions/2024/800x510/CC24_WLJH74_2TB_PAS_APA_XXX_XXX_XXX.c2e1e96a65ef99a7ae01e2889c95811d.png" alt="Car 5" class="car-image">
                <div class="car-details">
                    <h3 class="car-title">2024 Jeep Grand Cherokee</h3>
                    <p class="car-price">₱5,490,000</p>
                    <div class="car-specs">
                        <span>19/26 MPG</span>
                        <span>3.6L V6</span>
                        <span>4WD</span>
                    </div>
                    <a href="browseInventory.php" class="btn" rel="noopener noreferrer">View Details</a>
                </div>
            </div>
            
            <!-- Car 6 -->
            <div class="car-card">
                <img src="https://mystrongad.com/BMW/2024/3%20Series/2024-BMW-3-Series-Gray.webp" alt="Car 6" class="car-image">
                <div class="car-details">
                    <h3 class="car-title">2024 BMW 3 Series</h3>
                    <p class="car-price">P3,590,000</p>
                    <div class="car-specs">
                        <span>26/36 MPG</span>
                        <span>2.0L Turbo</span>
                        <span>RWD</span>
                    </div>
                    <a href="browseInventory.php" class="btn" rel="noopener noreferrer">View Details</a>
                </div>
            </div>
        </div>
    </section>


    <footer>
        <div class="copyright">
            <p>&copy; 2025 DRIVE Vehicle Enterprises. All rights reserved.</p>
            <p>Developed by Caille Aquino, Jeward Oliva, Francois Gabriel Osea</p>
        </div>
    </footer>

    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});
    </script>
</body>
</html>