<?php
session_start();
require_once '../db-connection.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db = new Database();
    $conn = $db->conn;

    // Get form data
    $vehicle_id = $conn->real_escape_string($_POST['vehicle_id']);
    $quantity = $conn->real_escape_string($_POST['quantity']);
    $address = $conn->real_escape_string($_POST['address']);
    $user_id = $_SESSION['user_id'];

    // Validate quantity
    if ($quantity < 1) {
        $_SESSION['error'] = "Quantity must be at least 1";
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }

    // Check vehicle availability
    $check_sql = "SELECT vi.*, v.brand, v.model 
                 FROM VehicleInventory vi
                 JOIN Vehicle v ON vi.vehicle_id = v.vehicle_id
                 WHERE vi.vehicle_id = '$vehicle_id' AND vi.status = 'available' AND vi.quantity >= $quantity";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows === 0) {
        $_SESSION['error'] = "Vehicle not available or quantity exceeds stock";
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }

    $vehicle = $check_result->fetch_assoc();

    // Handle file upload (receipt image)
    $receipt_image = null;
    if (isset($_FILES['receipt_image']) && $_FILES['receipt_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/receipts/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_ext = pathinfo($_FILES['receipt_image']['name'], PATHINFO_EXTENSION);
        $file_name = 'receipt_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
        $target_path = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES['receipt_image']['tmp_name'], $target_path)) {
            $receipt_image = $target_path;
        }
    }

    // Start transaction
    $conn->begin_transaction();

    try {
        // Insert order
        $order_sql = "INSERT INTO Orders (user_id, vehicle_id, quantity, address, receipt_image)
                     VALUES ('$user_id', '$vehicle_id', '$quantity', '$address', " . 
                     ($receipt_image ? "'$receipt_image'" : "NULL") . ")";
        $conn->query($order_sql);

        // Update inventory
        $update_sql = "UPDATE VehicleInventory 
                       SET quantity = quantity - $quantity,
                           status = CASE WHEN (quantity - $quantity) <= 0 THEN 'sold out' ELSE status END
                       WHERE vehicle_id = '$vehicle_id'";
        $conn->query($update_sql);

        $conn->commit();

        $_SESSION['success'] = "Order placed successfully for {$vehicle['brand']} {$vehicle['model']} (Quantity: $quantity)";
        header('Location: orders.php'); // Redirect to orders page
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = "Error processing order: " . $e->getMessage();
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
} else {
    header('Location: index.php');
    exit;
}