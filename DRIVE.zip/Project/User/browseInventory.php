<?php
session_start();

// Include database connection
require_once '../db-connection.php';
$db = new Database();
$conn = $db->conn;

// Function to get all available vehicles with inventory information
function getAvailableVehicles() {
    global $conn;
    
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $sql = "SELECT v.vehicle_id, v.brand, v.model, v.year, v.image_url, v.specifications, 
                   vi.price, vi.quantity, vi.status 
            FROM Vehicle v
            JOIN VehicleInventory vi ON v.vehicle_id = vi.vehicle_id
            WHERE vi.status = 'available' AND vi.quantity > 0";
    
    // Add search conditions if search term is provided
    if (!empty($search)) {
        $searchTerm = $conn->real_escape_string($search);
        $sql .= " AND (v.brand LIKE '%$searchTerm%' 
                      OR v.model LIKE '%$searchTerm%' 
                      OR v.year LIKE '%$searchTerm%'
                      OR v.specifications LIKE '%$searchTerm%')";
    }
    
    $sql .= " ORDER BY vi.date_added DESC";
    
    $result = $conn->query($sql);
    $vehicles = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $vehicles[] = $row;
        }
    }
    
    return $vehicles;
}
// Function to get single vehicle details by ID
function getVehicleById($id) {
    global $conn;
    
    $id = $conn->real_escape_string($id);
    $sql = "SELECT v.vehicle_id, v.brand, v.model, v.year, v.image_url, v.specifications, 
                   vi.price, vi.quantity, vi.status 
            FROM Vehicle v
            JOIN VehicleInventory vi ON v.vehicle_id = vi.vehicle_id
            WHERE v.vehicle_id = '$id'";
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// Format price with Philippine Peso sign
function formatPrice($price) {
    return '₱' . number_format($price, 2);
}

// Get all available vehicles
$vehicles = getAvailableVehicles();



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Inventory</title>
    <link rel="icon" type="image/x-icon" href="/Project/sign.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DRIVE - Vehicle Enterprises</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background-color: #ffffff;
    color: #1b1b1b;
    line-height: 1.6;
}

/* Header & Navigation */
/* Header & Navigation */
header {
    background-color: #1b1b1b;
    color: white;
    padding: 1rem 0;
    position: sticky;
    top: 0;
    z-index: 100;
}

.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
}

.logo {
    font-size: 2rem;
    font-weight: 700;
    color: #ffa31a;
    text-decoration: none;
}

.nav-menu {
    display: flex;
    list-style: none;
}

.nav-link {
    color: white;
    text-decoration: none;
    padding: 0.5rem 1rem;
    transition: background-color 0.3s;
}

.nav-link:hover {
    background-color: #ffa31a;
    border-radius: 4px;
}

.nav-right {
    display: flex;
    align-items: center;
}

.auth-buttons {
    display: flex;
    gap: 0.5rem;
    margin-left: 1rem;
}

.auth-btn {
    background-color: transparent;
    color: white;
    border: 1px solid #ffa31a;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
    cursor: pointer;
}

.auth-btn:hover {
    background-color: #ffa31a;
    color: #1b1b1b;
}

.auth-btn.primary {
    background-color: #ffa31a;
    color: #1b1b1b;
}

        

      

        .section-title {
            text-align: center;
            font-size: 2rem;
            color: var(--text-color);
            margin: 2rem 0;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .section-title::after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--primary-color);
        }

        .car-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 2rem;
            padding: 0 5%;
            margin-bottom: 3rem;
        }

        .car-card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .car-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 16px rgba(0, 0, 0, 0.2);
        }

        .car-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 3px solid var(--primary-color);
        }

        .car-content {
            padding: 1.5rem;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .car-title {
            font-size: 1.2rem;
            margin: 0 0 0.5rem 0;
            color: var(--text-color);
        }

        .car-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .car-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #666;
        }

        .car-meta span {
            display: flex;
            align-items: center;
        }

        .car-meta i {
            margin-right: 5px;
            color: var(--primary-color);
        }

        .view-details {
            background-color: #ffa31a;
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
            margin-top: auto;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .view-details:hover {
            background-color:  #ffa31a;
        }

        .view-details i {
            margin-left: 8px;
        }

        .no-vehicles {
            grid-column: 1 / -1;
            text-align: center;
            padding: 3rem;
            font-size: 1.2rem;
            color: #666;
        }

        /* Modal Styles */
        .modal {
    display: none;
    position: fixed;
    z-index: 1100;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.7);
    opacity: 0;
    transition: opacity 0.3s ease;
    backdrop-filter: blur(5px);
}

.modal.active {
    opacity: 1;
}

.modal-content {
    background-color: white;
    margin: 3% auto;
    width: 85%;
    max-width: 1000px;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    position: relative;
    animation: modalSlideDown 0.4s;
    overflow: hidden;
    border: none;
}

@keyframes modalSlideDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.close-modal {
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 1.8rem;
    color: white;
    cursor: pointer;
    transition: all 0.3s;
    z-index: 10;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background-color: rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(2px);
}

.close-modal:hover {
    color: #ffa31a;
    background-color: rgba(0, 0, 0, 0.5);
    transform: rotate(90deg);
}

.modal-header {
    background: linear-gradient(135deg, #1b1b1b 0%, #ffa31a 100%);
    color: white;
    padding: 2rem;
    position: relative;
    min-height: 180px;
}

.modal-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.3);
}

.modal-title {
    margin: 0;
    font-size: 2.2rem;
    font-weight: 700;
    position: relative;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.modal-subtitle {
    font-size: 1.2rem;
    opacity: 0.9;
    margin-top: 0.5rem;
    position: relative;
    font-weight: 400;
}

.modal-body {
    padding: 2.5rem;
    display: flex;
    flex-wrap: wrap;
    gap: 3rem;
}

.modal-image {
    flex: 1;
    min-width: 350px;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    height: 350px;
}

.modal-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.modal-image:hover img {
    transform: scale(1.03);
}

.modal-info {
    flex: 1;
    min-width: 350px;
}

.modal-price {
    font-size: 2.5rem;
    font-weight: 700;
    color: #ffa31a;
    margin: 1rem 0 2rem;
    display: flex;
    align-items: center;
}

.modal-price .price-label {
    font-size: 1rem;
    font-weight: 400;
    color: #666;
    margin-left: 10px;
}

.info-section {
    margin-bottom: 2rem;
}

.info-section h3 {
    font-size: 1.3rem;
    color: #1b1b1b;
    margin-bottom: 1.5rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid #ffa31a;
    display: inline-block;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
}

.info-row {
    margin-bottom: 1.2rem;
}

.info-label {
    font-size: 0.95rem;
    color: #666;
    margin-bottom: 0.3rem;
    font-weight: 500;
    display: flex;
    align-items: center;
}

.info-label i {
    margin-right: 8px;
    color: #ffa31a;
}

.info-value {
    font-size: 1.1rem;
    font-weight: 600;
    color: #333;
}

.specs-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
}

.spec-item {
    background: #f9f9f9;
    padding: 1rem;
    border-radius: 8px;
    border-left: 4px solid #ffa31a;
}

.spec-label {
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 0.3rem;
}

.spec-value {
    font-size: 1rem;
    font-weight: 500;
}

.modal-actions {
    margin-top: 2.5rem;
    display: flex;
    gap: 1.2rem;
    flex-wrap: wrap;
}

.action-btn {
    padding: 1rem 2rem;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 180px;
}

.action-btn.primary {
    background-color: #ffa31a;
    color: white;
    box-shadow: 0 4px 8px rgba(255, 163, 26, 0.3);
}

.action-btn.secondary {
    background-color: transparent;
    border: 2px solid #ffa31a;
    color: #ffa31a;
}

.action-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

.action-btn.primary:hover {
    background-color: #e69117;
}

.action-btn.secondary:hover {
    background-color: rgba(255, 163, 26, 0.1);
}

.action-btn i {
    margin-right: 10px;
    font-size: 1.1rem;
}

/* Order Form Styles */
#orderForm {
    display: none;
    margin-top: 2.5rem;
    background: #f8f8f8;
    padding: 2rem;
    border-radius: 10px;
    border: 1px solid #eee;
    animation: fadeIn 0.4s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

#orderForm h3 {
    font-size: 1.4rem;
    color: #1b1b1b;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
}

#orderForm h3 i {
    margin-right: 10px;
    color: #ffa31a;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #555;
}

.form-group input {
    width: 100%;
    padding: 0.8rem 1rem;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 1rem;
    transition: all 0.3s;
}

.form-group input:focus {
    border-color: #ffa31a;
    box-shadow: 0 0 0 3px rgba(255, 163, 26, 0.2);
    outline: none;
}

.form-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
}

/* Responsive Styles */
@media (max-width: 992px) {
    .modal-content {
        width: 90%;
        margin: 5% auto;
    }
    
    .modal-body {
        padding: 1.8rem;
    }
    
    .modal-image, .modal-info {
        min-width: 100%;
    }
    
    .info-grid, .specs-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 576px) {
    .modal-content {
        width: 95%;
        margin: 2% auto;
    }
    
    .modal-header {
        padding: 1.5rem;
        min-height: 150px;
    }
    
    .modal-title {
        font-size: 1.8rem;
    }
    
    .modal-body {
        padding: 1.5rem;
        gap: 2rem;
    }
    
    .modal-price {
        font-size: 2rem;
    }
    
    .action-btn {
        width: 100%;
    }
    
    .form-actions {
        flex-direction: column;
    }
        }
        .user-menu {
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-account {
    display: flex;
    align-items: center;
    color: #ffa31a;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s;
}


.user-account:before {
    content: '👤';
    margin-right: 5px;
    font-size: 1.2rem;
}  
.search-results-message {
    text-align: center;
    margin: 20px 0;
    font-size: 1.1rem;
    color: #666;
    padding: 0 5%;
}

.search-results-message strong {
    color: #ffa31a;
    font-weight: 600;
}
</style>
</head>
<body>
    <!-- Header and Navigation -->
  <header>
        <nav class="navbar">
            <a href="index.php" class="logo">DRIVE</a>
            <ul class="nav-menu">
                <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="browseInventory.php" class="nav-link">Inventory</a></li>
                <li class="nav-item"><a href="orders.php" class="nav-link">Orders</a></li>
            </ul>
            <div class="nav-right">
                <?php if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <!-- User is logged in -->
                    <div class="user-menu">
                        <a href="account.php" class="user-account">My Account</a>
                        <a href="logout.php" class="auth-btn">Logout</a>
                    </div>
                <?php else: ?>
                    <!-- User is not logged in -->
                    <div class="auth-buttons">
                        <a href="login.php" class="auth-btn" id="loginBtn">Login</a>
                        <a href="signup.php" class="auth-btn primary" id="signupBtn">Sign Up</a>
                    </div>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <h2 class="section-title">Browse Our Inventory</h2>
    <div class="search-container" style="margin: 20px auto; max-width: 800px; padding: 0 5%;">
    <form id="searchForm" method="get" style="display: flex; gap: 10px;">
        <input type="text" name="search" id="searchInput" 
               placeholder="Search by brand, model, or year..." 
               style="flex: 1; padding: 12px; border: 1px solid #ddd; border-radius: 5px;"
               value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit" style="background-color: #ffa31a; color: white; border: none; 
               padding: 12px 20px; border-radius: 5px; cursor: pointer;">
            <i class="fas fa-search"></i> Search
        </button>
        <?php if(isset($_GET['search']) && !empty($_GET['search'])): ?>
            <a href="browseInventory.php" style="background-color: #f0f0f0; color: #333; border: none; 
               padding: 12px 20px; border-radius: 5px; cursor: pointer; text-decoration: none;">
                <i class="fas fa-times"></i> Clear
            </a>
        <?php endif; ?>
    </form>
</div>
    <div class="car-grid">
        <?php if(empty($vehicles)): ?>
            <p class="no-vehicles">No vehicles currently in inventory. Please check back later.</p>
        <?php else: ?>
            <?php foreach($vehicles as $vehicle): ?>
                <div class="car-card">
                    <img 
                        src="<?php 
                            echo !empty($vehicle['image_url'])
                            ? '../Admin/' . htmlspecialchars($vehicle['image_url'], ENT_QUOTES)
                            : 'assets/img/no-image.png';
                        ?>" 
                        alt="<?php echo htmlspecialchars($vehicle['brand'] . ' ' . $vehicle['model'], ENT_QUOTES);?>" 
                        class="car-image"
                    >
                    <div class="car-content">
                        <h3 class="car-title"><?php echo htmlspecialchars($vehicle['year'] . ' ' . $vehicle['brand'] . ' ' . $vehicle['model']); ?></h3>
                        <p class="car-price"><?php echo formatPrice($vehicle['price']); ?></p>
                        <div class="car-meta">
                            <span><i class="fas fa-car"></i> <?php echo htmlspecialchars($vehicle['model']); ?></span>
                            <span><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars($vehicle['year']); ?></span>
                        </div>
                        <button class="view-details" data-vehicle-id="<?php echo $vehicle['vehicle_id']; ?>">
                            View Details <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Vehicle Details Modal -->
    <div id="vehicleModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <div id="vehicleDetails">
                <!-- Vehicle details will be loaded here via AJAX -->
            </div>
        </div>
    </div>
        <div id="vehicleModal" class="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <div id="vehicleDetails">
            <!-- Vehicle details will be loaded here via AJAX -->
        </div>
    </div>
</div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var modal = document.getElementById('vehicleModal');
            var detailsButtons = document.querySelectorAll('.view-details');
            var closeModal = document.querySelector('.close-modal');
            
            // Open modal when View Details button is clicked
            detailsButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    var vehicleId = this.getAttribute('data-vehicle-id');
                    loadVehicleDetails(vehicleId);
                    modal.style.display = 'block';
                    setTimeout(function() {
                        modal.classList.add('active');
                    }, 10);
                });
            });
            
            // Close modal when X is clicked
            closeModal.addEventListener('click', function() {
                closeModalFunction();
            });
            
            // Close modal when clicking outside the modal
            window.addEventListener('click', function(event) {
                if (event.target == modal) {
                    closeModalFunction();
                }
            });
            
            // Function to close modal with animation
            function closeModalFunction() {
                modal.classList.remove('active');
                setTimeout(function() {
                    modal.style.display = 'none';
                }, 300);
            }
            
            // Function to load vehicle details via AJAX
            function loadVehicleDetails(vehicleId) {
                // In a real implementation, this would be an AJAX call
                // For this demo, we'll simulate it with direct HTML
                
                // Get the vehicle data from the page
                var vehicles = <?php echo json_encode($vehicles); ?>;
                var vehicle = null;
                
                // Find the vehicle with matching ID
                for (var i = 0; i < vehicles.length; i++) {
                    if (vehicles[i].vehicle_id == vehicleId) {
                        vehicle = vehicles[i];
                        break;
                    }
                }
                
                if (vehicle) {
                    // Format the price
                    var formattedPrice = '₱' + parseFloat(vehicle.price).toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    });
                    
                    // Parse specifications if it's a JSON string
                    var specs = '';
                    try {
                        var specsObj = JSON.parse(vehicle.specifications);
                        for (var key in specsObj) {
                            if (specsObj.hasOwnProperty(key)) {
                                specs += '<div class="info-row"><div class="info-label">' + key + '</div>';
                                specs += '<div class="info-value">' + specsObj[key] + '</div></div>';
                            }
                        }
                    } catch (e) {
                        // If not JSON, just display as is
                        specs = '<div class="info-row"><div class="info-value">' + vehicle.specifications + '</div></div>';
                    }
                    
                    // Create HTML for the modal
                    var html = `
                        <div class="modal-header">
                            <h2 class="modal-title">${vehicle.year} ${vehicle.brand} ${vehicle.model}</h2>
                        </div>
                        <div class="modal-body">
                            <div class="modal-image">
                                <img src="${vehicle.image_url ? '../Admin/' + vehicle.image_url : 'assets/img/no-image.png'}" 
                                     alt="${vehicle.brand} ${vehicle.model}">
                            </div>
                            <div class="modal-info">
                                <div class="modal-price">${formattedPrice}</div>
                                
                                <div class="info-row">
                                    <div class="info-label">Brand</div>
                                    <div class="info-value">${vehicle.brand}</div>
                                </div>
                                
                                <div class="info-row">
                                    <div class="info-label">Model</div>
                                    <div class="info-value">${vehicle.model}</div>
                                </div>
                                
                                <div class="info-row">
                                    <div class="info-label">Year</div>
                                    <div class="info-value">${vehicle.year}</div>
                                </div>
                                
                                <div class="info-row">
                                    <div class="info-label">Availability</div>
                                    <div class="info-value">${vehicle.quantity > 0 ? 'In Stock (' + vehicle.quantity + ')' : 'Out of Stock'}</div>
                                </div>
                                
                                <h3>Specifications</h3>
                                ${specs}
                                
                                <div class="modal-actions">
                                    <button id="orderButton" class="action-btn primary" data-vehicle-id="${vehicle.vehicle_id}">
                                        <i class="fas fa-shopping-cart"></i> Order Now
                                    </button>
                                </div>
                                
   <div id="orderForm" style="display:none;">
    <h3><i class="fas fa-file-invoice"></i> Order Details</h3>
    <form id="vehicleOrderForm" enctype="multipart/form-data">
        <input type="hidden" name="vehicle_id" value="${vehicle.vehicle_id}">
        
        <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
            <div class="form-group" style="flex: 1;">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" max="${vehicle.quantity}" value="1" required 
                       style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
            </div>
        </div>
        
        <div class="form-group">
            <label for="delivery_address">Delivery Address:</label>
            <input type="text" id="delivery_address" name="delivery_address" required 
                   placeholder="Enter complete delivery address"
                   style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
        </div>
        
        <div class="form-group">
            <label>Payment Method:</label>
            <div class="payment-options" style="margin-top: 10px;">
                <!-- Bank Transfer Option -->
                <div class="payment-option" style="margin-bottom: 15px; padding: 15px; border: 1px solid #eee; border-radius: 8px;">
                    <input type="radio" id="bank-transfer" name="payment_method" value="Bank Transfer" checked 
                           style="margin-right: 10px;">
                    <label for="bank-transfer" style="display: inline-flex; align-items: center; font-weight: 600;">
                        <i class="fas fa-university" style="margin-right: 10px; color: #ffa31a; font-size: 1.2rem;"></i>
                        Bank Transfer
                    </label>
                    <div id="bank-details" class="payment-details" style="margin-left: 25px; margin-top: 15px;">
                        <div style="margin-bottom: 15px; background: #f9f9f9; padding: 15px; border-radius: 8px;">
                            <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                <img src="https://logo.clearbit.com/bdo.com.ph" alt="BDO" style="height: 30px; margin-right: 15px;">
                                <div>
                                    <strong style="display: block;">BDO (Banco de Oro)</strong>
                                    <div style="font-size: 0.9rem; color: #555;">
                                        <div>Account: <strong>123 456 7890</strong></div>
                                        <div>Name: <strong>DRIVE Vehicle Enterprises</strong></div>
                                        <div>Branch: <strong>SM City Manila</strong></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: #f9f9f9; padding: 15px; border-radius: 8px;">
                            <div style="display: flex; align-items: center;">
                                <img src="https://logo.clearbit.com/bpi.com.ph" alt="BPI" style="height: 30px; margin-right: 15px;">
                                <div>
                                    <strong style="display: block;">BPI (Bank of the Philippine Islands)</strong>
                                    <div style="font-size: 0.9rem; color: #555;">
                                        <div>Account: <strong>9876 543 210</strong></div>
                                        <div>Name: <strong>DRIVE Vehicle Enterprises</strong></div>
                                        <div>Branch: <strong>Ayala Avenue</strong></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Credit/Debit Card Option -->
                <div class="payment-option" style="margin-bottom: 15px; padding: 15px; border: 1px solid #eee; border-radius: 8px;">
                    <input type="radio" id="card-payment" name="payment_method" value="Credit/Debit Card" 
                           style="margin-right: 10px;">
                    <label for="card-payment" style="display: inline-flex; align-items: center; font-weight: 600;">
                        <i class="far fa-credit-card" style="margin-right: 10px; color: #ffa31a; font-size: 1.2rem;"></i>
                        Credit/Debit Card
                    </label>
                    <div id="card-details" class="payment-details" style="margin-left: 25px; margin-top: 15px; display: none;">
                        <div style="background: #f9f9f9; padding: 15px; border-radius: 8px;">
                            <div style="display: flex; align-items: center; margin-bottom: 10px;">
                                <div style="display: flex; gap: 10px; margin-right: 15px;">
                                    <img src="https://logo.clearbit.com/visa.com" alt="Visa" style="height: 20px;">
                                    <img src="https://logo.clearbit.com/mastercard.com" alt="Mastercard" style="height: 20px;">
                                </div>
                                <div>
                                    <div style="font-size: 0.9rem; color: #555;">
                                        We accept Visa and Mastercard payments through our secure payment gateway.
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group" style="margin-top: 15px;">
                                <label for="card_number">Card Number</label>
                                <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" 
                                       style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                            </div>
                            
                            <div style="display: flex; gap: 15px; margin-top: 10px;">
                                <div class="form-group" style="flex: 1;">
                                    <label for="expiry_date">Expiry Date</label>
                                    <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY" 
                                           style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                                </div>
                                <div class="form-group" style="flex: 1;">
                                    <label for="cvv">CVV</label>
                                    <input type="text" id="cvv" name="cvv" placeholder="123" 
                                           style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="form-group">
            <label for="receipt_image">Upload Payment Proof:</label>
            <input type="file" id="receipt_image" name="receipt_image" accept="image/*" required
                   style="width: 100%; padding: 5px;">
            <small style="display: block; margin-top: 5px; color: #666;">
                For bank transfers: Upload screenshot of transaction<br>
                For card payments: Upload screenshot of payment confirmation
            </small>
        </div>
        
        <div class="form-actions" style="display: flex; gap: 15px; margin-top: 20px;">
            <button type="submit" class="action-btn primary" style="flex: 1;">
                <i class="fas fa-check"></i> Confirm Order
            </button>
            <button type="button" id="cancelOrder" class="action-btn secondary" style="flex: 1;">
                <i class="fas fa-times"></i> Cancel
            </button>
        </div>
    </form>
</div>
                    `;
                    
                    document.getElementById('vehicleDetails').innerHTML = html;
                    
                    // Add event listener for the order button
                    document.getElementById('orderButton').addEventListener('click', function() {
                        this.style.display = 'none';
                        document.getElementById('orderForm').style.display = 'block';
                    });
                    
                    // Add event listener for the cancel button
                    document.getElementById('cancelOrder').addEventListener('click', function() {
                        document.getElementById('orderForm').style.display = 'none';
                        document.getElementById('orderButton').style.display = 'block';
                    });
                    
                    // Handle form submission
         document.getElementById('vehicleOrderForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const userId = <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>;
    
    if (userId === null) {
        alert("Please log in to place an order.");
        window.location.href = "login.php";
        return;
    }
    
    // Create a FormData object from the form
   const formData = new FormData(this);
    
    // Get the delivery address from the form input field
    const deliveryAddress = document.getElementById('delivery_address').value;
    if (!deliveryAddress) {
        alert("Delivery address is required to place an order.");
        return;
    }
    
    // Add receipt image upload capability (add file input to your form)
    const receiptImage = document.getElementById('receipt_image').files[0];
    if (receiptImage) {
        formData.append('receipt_image', receiptImage);
    }
    
    // Submit the form via AJAX
    fetch('process_order.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        // Handle response - redirect or show success message
        window.location.href = "orders.php"; // Redirect to orders page
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred while processing your order.");
    });
});
                }
            }
        });
    </script>
</body>
</html>