<?php
require_once '../db-connection.php';

session_start(); 

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle signup form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize database connection
    try {
        $db = new Database();
        $conn = $db->conn;
    } catch (Exception $e) {
        // Log the error and show a user-friendly message
        error_log($e->getMessage());
        die("Sorry, we're experiencing technical difficulties. Please try again later.");
    }

    // Sanitize and validate input
    $full_name = trim($conn->real_escape_string($_POST['fullName']));
    $email = trim($conn->real_escape_string($_POST['email']));
    $phone = trim($conn->real_escape_string($_POST['phone']));
    $password = $_POST['password'];
    $confirm_password = $_POST['confirmPassword'];

    // Validate input
    $errors = [];

    // Validate all required fields
    if (empty($full_name)) {
        $errors[] = "Full name is required.";
    }

    if (empty($email)) {
        $errors[] = "Email address is required.";
    }

    if (empty($phone)) {
        $errors[] = "Phone number is required.";
    }


    // Check if passwords match
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    // Check password strength
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }

    // Check if email already exists
    $email_check_query = "SELECT user_id FROM Users WHERE email = ?";
    $stmt = $conn->prepare($email_check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $errors[] = "Email already exists.";
    }
    $stmt->close();

    // If no errors, proceed with registration
    if (empty($errors)) {
        // Hash the password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL to insert new user
        $insert_query = "INSERT INTO Users (full_name, email, phone,  password_hash) VALUES (?, ?, ?,? )";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ssss", $full_name, $email, $phone, $password_hash);

        try {
            if ($stmt->execute()) {
                // Redirect to login page with success message
                $_SESSION['signup_success'] = "Account created successfully. Please log in.";
                header("Location: login.php");
                exit();
            } else {
                $errors[] = "Error creating account: " . $stmt->error;
            }
        } catch (Exception $e) {
            $errors[] = "Registration failed. Please try again.";
            error_log("Signup error: " . $e->getMessage());
        } finally {
            $stmt->close();
        }
    }

    // Close database connection
    $db->closeConnection();

    // If there are errors, pass them back to the signup page
    if (!empty($errors)) {
        $_SESSION['signup_errors'] = $errors;
        header("Location: signup.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Signup</title>
    <link rel="icon" type="image/x-icon" href="/Project/sign.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - DRIVE Vehicle Enterprises</title>
    <link rel="stylesheet" href="Style/styles.css">
</head>
<body>
    <!-- Header and Navigation -->
    <header>
        <nav class="navbar">
            <a href="index.php" class="logo">DRIVE</a>
            <ul class="nav-menu">
                <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="browseInventory.php" class="nav-link">Inventory</a></li>
                <li class="nav-item"><a href="orders.php" class="nav-link">Orders</a></li>
            </ul>
            <div class="nav-right">
                <div class="auth-buttons">
                    <a href="login.php" class="auth-btn">Login</a>
                    <a href="signup.php" class="auth-btn primary">Sign Up</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Signup Container -->
    <section class="contact" style="min-height: calc(100vh - 300px);">
        <div class="contact-form">
            <h2 class="section-title">Sign Up</h2>
            
            <?php
            // Display success message
            if (isset($_SESSION['signup_success'])) {
                echo '<div class="success-message">';
                echo "<p class='success'>" . htmlspecialchars($_SESSION['signup_success']) . "</p>";
                echo '</div>';
                unset($_SESSION['signup_success']);
            }

            // Display errors if any
            if (isset($_SESSION['signup_errors'])) {
                echo '<div class="error-messages">';
                foreach ($_SESSION['signup_errors'] as $error) {
                    echo "<p class='error'>" . htmlspecialchars($error) . "</p>";
                }
                echo '</div>';
                unset($_SESSION['signup_errors']); // Clear the errors
            }
            ?>
            
            <form action="signup.php" method="POST">
                <div class="form-group">
                    <label for="fullName">Full Name</label>
                    <input type="text" id="fullName" name="fullName" class="form-control" required placeholder="Enter your full name">
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" required placeholder="Enter your email">
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control" required placeholder="Enter your phone number">
                </div>

              
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required 
                           placeholder="Minimum 8 characters" minlength="8">
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" required 
                           placeholder="Repeat your password">
                </div>
                
                <button type="submit" class="btn" style="width: 100%; margin-top: 1rem;">Create Account</button>
            </form>
            
            <div class="auth-toggle">
                <p>Already have an account? <a href="login.php">Login here</a></p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="copyright">
            <p>&copy; 2025 DRIVE Vehicle Enterprises. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>