<?php
session_start();
require_once '../db-connection.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$db = new Database();
$conn = $db->conn;

// Get user's orders
$user_id = $_SESSION['user_id'];
$sql = "SELECT o.*, v.brand, v.model, v.image_url, vi.price 
        FROM Orders o
        JOIN Vehicle v ON o.vehicle_id = v.vehicle_id
        JOIN VehicleInventory vi ON o.vehicle_id = vi.vehicle_id
        WHERE o.user_id = '$user_id'
        ORDER BY o.order_date DESC";
$result = $conn->query($sql);
$orders = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}

// Get status colors for display
function getStatusColor($status) {
    switch($status) {
        case 'pending': return '#ffc107';
        case 'processing': return '#17a2b8';
        case 'shipped': return '#007bff';
        case 'delivered': return '#28a745';
        case 'cancelled': return '#dc3545';
        default: return '#6c757d';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Orders</title>
    <link rel="icon" type="image/x-icon" href="/Project/sign.png">

    <!-- Keep the same head section as before, just add this to the style -->
    <style>
        /* Add to existing styles */
        .order-status {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 1rem;
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .status-tracker {
            display: flex;
            justify-content: space-between;
            margin: 1.5rem 0;
            position: relative;
        }
        
        .status-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            z-index: 1;
            flex: 1;
        }
        
        .status-icon {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.5rem;
            background-color: #e0e0e0;
            color: #9e9e9e;
        }
        
        .status-icon.active {
            background-color: var(--primary-color);
            color: var(--dark-color);
        }
        
        .status-label {
            font-size: 0.8rem;
            text-align: center;
            color: #9e9e9e;
        }
        
        .status-label.active {
            color: var(--dark-color);
            font-weight: 600;
        }
        
        .status-connector {
            position: absolute;
            top: 18px;
            left: 0;
            right: 0;
            height: 2px;
            background-color: #e0e0e0;
            z-index: 0;
        }
        
        .status-progress {
            position: absolute;
            top: 18px;
            left: 0;
            height: 2px;
            background-color: var(--primary-color);
            z-index: 1;
            transition: width 0.5s ease;
        }
        
        .cancel-btn {
            background-color: #f8f9fa;
            color: #dc3545;
            border: 1px solid #dc3545;
        }
        
        .cancel-btn:hover {
            background-color: #dc3545;
            color: white;
        }       :root {
            --primary-color: #ffa31a;
            --primary-dark: #e69117;
            --dark-color: #1b1b1b;
            --light-color: #ffffff;
            --gray-color: #f5f5f5;
            --text-color: #333333;
            --border-color: #e0e0e0;
            --success-color: #28a745;
            --error-color: #dc3545;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--gray-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        /* Header Styles (same as your main page) */
        header {
            background-color: var(--dark-color);
            color: var(--light-color);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .logo {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        /* Main Content */
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }

        .section-title {
            text-align: center;
            font-size: 2.2rem;
            color: var(--dark-color);
            margin: 2rem 0 3rem;
            position: relative;
            padding-bottom: 1rem;
        }

        .section-title::after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: 0;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background-color: var(--primary-color);
            border-radius: 2px;
        }

        /* Alert Messages */
        .alert {
            padding: 1rem;
            margin: 1rem auto;
            max-width: 800px;
            border-radius: 8px;
            text-align: center;
            font-weight: 500;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert-success {
            background-color: rgba(40, 167, 69, 0.1);
            color: var(--success-color);
            border: 1px solid rgba(40, 167, 69, 0.3);
        }

        .alert-error {
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--error-color);
            border: 1px solid rgba(220, 53, 69, 0.3);
        }

        /* Orders Container */
        .orders-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .order-card {
            background-color: var(--light-color);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
        }

        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }

        .order-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 3px solid var(--primary-color);
        }

        .order-content {
            padding: 1.5rem;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .order-title {
            font-size: 1.4rem;
            margin: 0 0 0.5rem 0;
            color: var(--dark-color);
            font-weight: 600;
        }

        .order-meta {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            margin: 1rem 0;
            font-size: 0.95rem;
        }

        .order-meta-item {
            display: flex;
            align-items: center;
        }

        .order-meta-item i {
            width: 24px;
            color: var(--primary-color);
            margin-right: 8px;
            text-align: center;
        }

        .order-price {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            margin: 1rem 0;
        }

        .order-actions {
            margin-top: auto;
            display: flex;
            gap: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .action-btn {
            padding: 0.7rem 1.2rem;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
        }

        .action-btn i {
            margin-right: 8px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: var(--dark-color);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            color: var(--light-color);
        }

        .btn-secondary {
            background-color: transparent;
            border: 1px solid var(--primary-color);
            color: var(--primary-color);
        }

        .btn-secondary:hover {
            background-color: var(--primary-color);
            color: var(--dark-color);
        }

        .no-orders {
            text-align: center;
            padding: 3rem;
            font-size: 1.2rem;
            color: #666;
            grid-column: 1 / -1;
        }

        .no-orders i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
            opacity: 0.7;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .orders-container {
                grid-template-columns: 1fr;
            }
            
            .section-title {
                font-size: 1.8rem;
                margin: 1.5rem 0;
            }
        }

        @media (max-width: 480px) {
            .order-actions {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
            }
        }
            .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        align-items: center;
        justify-content: center;
    }
    
    .modal-content {
        background-color: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
        animation: modalFadeIn 0.3s ease;
        width: 90%;
        max-width: 500px;
    }
    
    @keyframes modalFadeIn {
        from { opacity: 0; transform: translateY(-50px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .modal-header {
        padding: 1.5rem;
        background-color: var(--dark-color);
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-title {
        margin: 0;
        font-size: 1.3rem;
    }
    
    .close-modal {
        font-size: 1.8rem;
        cursor: pointer;
        transition: var(--transition);
    }
    
    .close-modal:hover {
        color: var(--primary-color);
    }
    
    .modal-body {
        padding: 1.5rem;
    }
    
    .form-group {
        margin-bottom: 1.5rem;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 600;
    }
    
    .form-group textarea {
        width: 100%;
        padding: 0.8rem;
        border: 1px solid var(--border-color);
        border-radius: 6px;
        resize: vertical;
        min-height: 100px;
        font-family: inherit;
    }
    
    .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        padding-top: 1rem;
    }
    
    .btn {
        padding: 0.7rem 1.5rem;
        border-radius: 6px;
        font-weight: 600;
        cursor: pointer;
        transition: var(--transition);
        border: none;
    }
    
    .btn-secondary {
        background-color: #f8f9fa;
        color: var(--text-color);
        border: 1px solid var(--border-color);
    }
    
    .btn-secondary:hover {
        background-color: #e9ecef;
    }
    
    .btn-danger {
        background-color: #dc3545;
        color: white;
    }
    
    .btn-danger:hover {
        background-color: #c82333;
    }  .user-menu {
    display: flex;
    align-items: center;
    gap: 15px;
}

.user-account {
    display: flex;
    align-items: center;
    color: #ffa31a;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s;
}


.user-account:before {
    content: '👤';
    margin-right: 5px;
    font-size: 1.2rem;
}  
/* Header & Navigation */
header {
    background-color: #1b1b1b;
    color: white;
    padding: 1rem 0;
    position: sticky;
    top: 0;
    z-index: 100;
}

.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
}

.logo {
    font-size: 2rem;
    font-weight: 700;
    color: #ffa31a;
    text-decoration: none;
}

.nav-menu {
    display: flex;
    list-style: none;
}

.nav-link {
    color: white;
    text-decoration: none;
    padding: 0.5rem 1rem;
    transition: background-color 0.3s;
}

.nav-link:hover {
    background-color: #ffa31a;
    border-radius: 4px;
}

.nav-right {
    display: flex;
    align-items: center;
}

.auth-buttons {
    display: flex;
    gap: 0.5rem;
    margin-left: 1rem;
}

.auth-btn {
    background-color: transparent;
    color: white;
    border: 1px solid #ffa31a;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
    cursor: pointer;
}

.auth-btn:hover {
    background-color: #ffa31a;
    color: #1b1b1b;
}

.auth-btn.primary {
    background-color: #ffa31a;
    color: #1b1b1b;
}

    </style>
</head>
<body>
     <header>
        <nav class="navbar">
            <a href="index.php" class="logo">DRIVE</a>
            <ul class="nav-menu">
                <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="browseInventory.php" class="nav-link">Inventory</a></li>
                <li class="nav-item"><a href="orders.php" class="nav-link">Orders</a></li>
            </ul>
            <div class="nav-right">
                <?php if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <!-- User is logged in -->
                    <div class="user-menu">
                        <a href="account.php" class="user-account">My Account</a>
                        <a href="logout.php" class="auth-btn">Logout</a>
                    </div>
                <?php else: ?>
                    <!-- User is not logged in -->
                    <div class="auth-buttons">
                        <a href="login.php" class="auth-btn" id="loginBtn">Login</a>
                        <a href="signup.php" class="auth-btn primary" id="signupBtn">Sign Up</a>
                    </div>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    
    <div class="container">
        <h1 class="section-title">My Orders</h1>
        
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if(empty($orders)): ?>
            <div class="no-orders">
                <i class="fas fa-box-open"></i>
                <h3>No Orders Yet</h3>
                <p>You haven't placed any orders yet. Browse our inventory to find your perfect vehicle!</p>
                <a href="index.php" class="action-btn btn-primary" style="margin-top: 1rem;">
                    <i class="fas fa-car"></i> Browse Vehicles
                </a>
            </div>
        <?php else: ?>
            <div class="orders-container">
                <?php foreach($orders as $order): 
                    $total_price = $order['price'] * $order['quantity'];
                    $order_date = date('F j, Y, g:i a', strtotime($order['order_date']));
                    $status_color = getStatusColor($order['status']);
                    
                    // Determine active steps for status tracker
                    $steps = ['pending', 'processing', 'shipped', 'delivered'];
                    $current_step = array_search($order['status'], $steps);
                    if ($current_step === false && $order['status'] === 'cancelled') {
                        $current_step = -1; // Cancelled state
                    }
                ?>
                    <div class="order-card">
                        <img src="<?php echo !empty($order['image_url']) ? '../Admin/' . htmlspecialchars($order['image_url']) : 'assets/img/no-image.png'; ?>" 
                             alt="<?php echo htmlspecialchars($order['brand'] . ' ' . $order['model']); ?>" 
                             class="order-image">
                        <div class="order-content">
                            <div class="order-status" style="background-color: rgba(<?php echo hexdec(substr($status_color, 1, 2)); ?>, <?php echo hexdec(substr($status_color, 3, 2)); ?>, <?php echo hexdec(substr($status_color, 5, 2)); ?>, 0.1); color: <?php echo $status_color; ?>;">
                                <?php echo ucfirst($order['status']); ?>
                            </div>
                            
                            <h3 class="order-title"><?php echo htmlspecialchars($order['brand'] . ' ' . $order['model']); ?></h3>
                            
                            <!-- Status Tracker -->
                            <?php if($order['status'] !== 'cancelled'): ?>
                            <div class="status-tracker">
                                <div class="status-connector"></div>
                                <div class="status-progress" style="width: <?php echo $current_step !== false ? ($current_step / (count($steps) - 1)) * 100 : 0; ?>%"></div>
                                
                                <?php foreach($steps as $index => $step): ?>
                                    <div class="status-step">
                                        <div class="status-icon <?php echo $index <= $current_step ? 'active' : ''; ?>">
                                            <?php if($index < $current_step): ?>
                                                <i class="fas fa-check"></i>
                                            <?php else: ?>
                                                <?php echo $index + 1; ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="status-label <?php echo $index <= $current_step ? 'active' : ''; ?>">
                                            <?php echo ucfirst($step); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="order-meta">
                                <div class="order-meta-item">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Ordered: <?php echo $order_date; ?></span>
                                </div>
                                <div class="order-meta-item">
                                    <i class="fas fa-cubes"></i>
                                    <span>Quantity: <?php echo $order['quantity']; ?></span>
                                </div>
                                <div class="order-meta-item">
                                    <i class="fas fa-tag"></i>
                                    <span>Unit Price: ₱<?php echo number_format($order['price'], 2); ?></span>
                                </div>
                            </div>
                            
                            <div class="order-price">
                                Total: ₱<?php echo number_format($total_price, 2); ?>
                            </div>
                            
                            <div class="order-actions">
                                <?php if($order['receipt_image']): ?>
                                    <a href="<?php echo $order['receipt_image']; ?>" target="_blank" class="action-btn btn-secondary">
                                        <i class="fas fa-receipt"></i> View Receipt
                                    </a>
                                <?php endif; ?>
                                
                                <?php if($order['status'] === 'pending' || $order['status'] === 'processing'): ?>
                                    <button class="action-btn cancel-btn request-cancel" data-order-id="<?php echo $order['order_id']; ?>">
                                        <i class="fas fa-times"></i> Cancel Order
                                    </button>
                                <?php endif; ?>
                                
                                <a href="index.php" class="action-btn btn-primary">
                                    <i class="fas fa-shopping-cart"></i> Order Again
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Cancel Order Modal -->
    <div id="cancelModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3 class="modal-title">Cancel Order</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to cancel this order? This action cannot be undone.</p>
                <form id="cancelOrderForm" method="POST" action="cancel-order.php">
                    <input type="hidden" name="order_id" id="cancelOrderId">
                    <div class="form-group">
                        <label for="cancel_reason">Reason for cancellation:</label>
                        <textarea name="cancel_reason" id="cancel_reason" rows="3" required></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-secondary close-modal-btn">No, Keep Order</button>
                        <button type="submit" class="btn btn-danger">Yes, Cancel Order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Cancel Order Modal
        const cancelModal = document.getElementById('cancelModal');
        const cancelButtons = document.querySelectorAll('.request-cancel');
        const cancelCloseModal = cancelModal.querySelector('.close-modal');
        const cancelCloseBtn = cancelModal.querySelector('.close-modal-btn');
        
        // Open cancel modal
        cancelButtons.forEach(button => {
            button.addEventListener('click', () => {
                const orderId = button.getAttribute('data-order-id');
                document.getElementById('cancelOrderId').value = orderId;
                cancelModal.style.display = 'flex';
            });
        });
        
        // Close cancel modal
        cancelCloseModal.addEventListener('click', () => {
            cancelModal.style.display = 'none';
        });
        
        cancelCloseBtn.addEventListener('click', () => {
            cancelModal.style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === cancelModal) {
                cancelModal.style.display = 'none';
            }
        });
    </script>
</body>
</html>