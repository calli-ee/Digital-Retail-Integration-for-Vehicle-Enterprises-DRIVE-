<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

require_once '../db-connection.php';

// Create database instance
try {
    $db = new Database();
    $conn = $db->conn;
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get user information from database
$userEmail = $_SESSION['user_email'];
$stmt = $conn->prepare("SELECT * FROM Users WHERE email = ?");
$stmt->bind_param("s", $userEmail);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_profile':
                $full_name = trim($_POST['full_name']);
                $phone = trim($_POST['phone']);
                
                // Validate input
                if (empty($full_name)) {
                    $error = "Full name is required.";
                } else {
                    try {
                        $stmt = $conn->prepare("UPDATE Users SET full_name = ?, phone = ? WHERE email = ?");
                        $stmt->bind_param("sss", $full_name, $phone, $userEmail);
                        
                        if ($stmt->execute()) {
                            $success = "Profile updated successfully!";
                            
                            // Update user data for display
                            $user['full_name'] = $full_name;
                            $user['phone'] = $phone;
                        } else {
                            $error = "Error updating profile: " . $conn->error;
                        }
                    } catch (Exception $e) {
                        $error = "Error updating profile: " . $e->getMessage();
                    }
                }
                break;
                
            case 'change_password':
                $current_password = $_POST['current_password'];
                $new_password = $_POST['new_password'];
                $confirm_password = $_POST['confirm_password'];
                
                // Validate input
                if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
                    $error = "All password fields are required.";
                } elseif ($new_password !== $confirm_password) {
                    $error = "New passwords do not match.";
                } elseif (strlen($new_password) < 6) {
                    $error = "New password must be at least 6 characters long.";
                } else {
                    // Verify current password
                    if (password_verify($current_password, $user['password_hash'])) {
                        try {
                            $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                            $stmt = $conn->prepare("UPDATE Users SET password_hash = ? WHERE email = ?");
                            $stmt->bind_param("ss", $new_password_hash, $userEmail);
                            
                            if ($stmt->execute()) {
                                $success = "Password changed successfully! Please log in again.";
                                $show_logout_modal = true;
                            } else {
                                $error = "Error updating password: " . $conn->error;
                            }
                        } catch (Exception $e) {
                            $error = "Error updating password: " . $e->getMessage();
                        }
                    } else {
                        $error = "Current password is incorrect.";
                    }
                }
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - DRIVE Vehicle Enterprises</title>
    <link rel="stylesheet" href="Style/styles.css">
    <style>
        .account-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .account-header {
            margin-bottom: 30px;
            text-align: center;
        }
        
        .account-details {
            margin-bottom: 30px;
        }
        
        .account-section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #eee;
            border-radius: 8px;
        }
        
        .account-section h3 {
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 15px;
            color: #333;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-group textarea {
            height: 80px;
            resize: vertical;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .btn-group.center {
            justify-content: center;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background-color: #ffa31a;
            color: white;
            border: 1px solid #ffa31a;
        }
        
        .btn-primary:hover {
            background-color:transparent;
            border: 1px solid #ffa31a;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .btn-secondary {
            background-color: #ffa31a;
            color: white;
            border: 1px solid #ffa31a;
        }
        
        .btn-secondary:hover {
            background-color: transparent;
            border: 1px solid #ffa31a;
        }
        
        .btn-warning {
            background-color: #ffc107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background-color: #e0a800;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-account {
            display: flex;
            align-items: center;
            color: #333;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .user-account:hover {
            color: #ffa31a;
        }

        .user-account:before {
            content: '👤';
            margin-right: 5px;
            font-size: 1.2rem;
        }

        .auth-btn {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            color: #333;
            background-color: transparent;
            border: 1px solid #ddd;
        }

        .auth-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background-color: #f5f5f5;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        
        .alert-error {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
        
        .info-item {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 4px;
        }
        
        .info-item strong {
            color: #333;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 30px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .modal h3 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .modal p {
            margin-bottom: 20px;
            color: #666;
        }
        
        .modal form {
            text-align: left;
        }
        
        .password-requirements {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 12px;
            color: #6c757d;
        }
        
        .password-requirements ul {
            margin: 5px 0;
            padding-left: 20px;
        }
        
        .modal-tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .modal-tab {
            flex: 1;
            padding: 10px;
            background: none;
            border: none;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
        }
        
        .modal-tab.active {
            border-bottom-color: #ffa31a;
            color: #ffa31a;
            font-weight: 500;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }
                .user-account {
            display: flex;
            align-items: center;
            color: #ffa31a;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .user-account:before {
            content: '👤';
            margin-right: 5px;
            font-size: 1.2rem;
        } .auth-buttons {
            display: flex;
            gap: 0.5rem;
            margin-left: 1rem;
        }

        .auth-btn {
            background-color: transparent;
            color: white;
            border: 1px solid #ffa31a;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
            cursor: pointer;
        }

        .auth-btn:hover {
            background-color: #ffa31a;
            color: #1b1b1b;
        }

        .auth-btn.primary {
            background-color: #ffa31a;
            color: #1b1b1b;
        }

</style>
</head>
<body>
    <!-- Header and Navigation -->
  <header>
        <nav class="navbar">
            <a href="#" class="logo">DRIVE</a>
            <ul class="nav-menu">
                <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                <li class="nav-item"><a href="#about" class="nav-link">About Us</a></li>
                <li class="nav-item"><a href="browseInventory.php" class="nav-link">Inventory</a></li>
                <li class="nav-item"><a href="orders.php" class="nav-link">Orders</a></li>

            </ul>
            <div class="nav-right">
                <?php if(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <!-- User is logged in -->
                    <div class="user-menu">
                        <a href="account.php" class="user-account">My Account</a>
                        <a href="logout.php" class="auth-btn">Logout</a>
                    </div>
                <?php else: ?>
                    <!-- User is not logged in -->
                    <div class="auth-buttons">
                        <a href="login.php" class="auth-btn" id="loginBtn">Login</a>
                        <a href="signup.php" class="auth-btn primary" id="signupBtn">Sign Up</a>
                    </div>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <!-- Account Container -->
    <div class="account-container">
        <div class="account-header">
            <h2 class="section-title">My Account</h2>
            <p>Welcome back, <?php echo htmlspecialchars($user['full_name'] ?? 'User'); ?>!</p>
        </div>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <div class="account-details">
            <!-- Current Account Information -->
            <div class="account-section">
                <h3>Current Account Information</h3>
                <div class="info-item">
                    <strong>Full Name:</strong> <?php echo htmlspecialchars($user['full_name'] ?? 'Not set'); ?>
                </div>
                <div class="info-item">
                    <strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?>
                </div>
                <div class="info-item">
                    <strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'Not set'); ?>
                </div>
                <div class="info-item">
                    <strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($user['created_at'])); ?>
                </div>
                
                <div class="btn-group">
                    <button type="button" class="auth-btn" onclick="showEditModal()">Edit Profile</button>
                    <button type="button" class="auth-btn" onclick="showPasswordModal()">Change Password</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-tabs">
                <button class="modal-tab active" onclick="showTab('profile')">Edit Profile</button>
                <button class="modal-tab" onclick="showTab('password')">Change Password</button>
            </div>
            
            <!-- Profile Tab -->
            <div id="profileTab" class="tab-content active">
                <h3>Edit Profile</h3>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-group">
                        <label for="modal_full_name">Full Name *</label>
                        <input type="text" id="modal_full_name" name="full_name" 
                               value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="modal_phone">Phone Number</label>
                        <input type="tel" id="modal_phone" name="phone" 
                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>
                    
                    <div class="btn-group">
                        <button type="button" class="btn btn-secondary" onclick="hideEditModal()">Cancel</button>
                        <button type="submit" class="auth-btn">Update Profile</button>
                    </div>
                </form>
            </div>
            
            <!-- Password Tab -->
            <div id="passwordTab" class="tab-content">
                <h3>Change Password</h3>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label for="current_password">Current Password *</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">New Password *</label>
                        <input type="password" id="new_password" name="new_password" required>
                        <div class="password-requirements">
                            <strong>Password Requirements:</strong>
                            <ul>
                                <li>At least 6 characters long</li>
                                <li>Mix of letters and numbers recommended</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password *</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    
                    <div class="btn-group">
                        <button type="button" class="btn btn-secondary" onclick="hideEditModal()">Cancel</button>
                        <button type="submit" class="auth-btn">Change Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Logout Confirmation Modal -->
    <div id="logoutModal" class="modal">
        <div class="modal-content">
            <h3>Confirm Logout</h3>
            <p>Are you sure you want to log out?</p>
            <div class="btn-group">
                <button class="btn btn-secondary" onclick="hideLogoutModal()">Cancel</button>
                <a href="logout.php" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </div>
    
    <!-- Password Change Success Modal -->
    <?php if (isset($show_logout_modal)): ?>
    <div id="passwordUpdateModal" class="modal" style="display: block;">
        <div class="modal-content">
            <h3>Password Changed Successfully!</h3>
            <p>Your password has been updated. For security reasons, you need to log in again with your new password.</p>
            <div class="btn-group center">
                <a href="logout.php" class="btn btn-primary">Log Out Now</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <footer>
        <div class="copyright">
            <p>&copy; 2025 DRIVE Vehicle Enterprises. All rights reserved.</p>
        </div>
    </footer>

    <script>
        function showEditModal() {
            document.getElementById('editModal').style.display = 'block';
        }
        
        function hideEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        function showPasswordModal() {
            document.getElementById('editModal').style.display = 'block';
            showTab('password');
        }
        
        function showLogoutModal() {
            document.getElementById('logoutModal').style.display = 'block';
        }
        
        function hideLogoutModal() {
            document.getElementById('logoutModal').style.display = 'none';
        }
        
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.modal-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabName + 'Tab').classList.add('active');
            event.target.classList.add('active');
        }
        
        // Password confirmation validation
        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            
            if (newPassword !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
        
        // Close modals when clicking outside
        window.onclick = function(event) {
            const logoutModal = document.getElementById('logoutModal');
            const editModal = document.getElementById('editModal');
            const passwordModal = document.getElementById('passwordUpdateModal');
            
            if (event.target === logoutModal) {
                hideLogoutModal();
            }
            if (event.target === editModal) {
                hideEditModal();
            }
            if (event.target === passwordModal) {
                passwordModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>